; ModuleID = 'LLVMDialectModule'
source_filename = "LLVMDialectModule"
target datalayout = "e-m:e-p:64:64-p1:64:64-p2:32:32-p3:32:32-p4:64:64-p5:32:32-p6:32:32-p7:160:256:256:32-p8:128:128:128:48-p9:192:256:256:32-i64:64-v16:16-v24:32-v32:32-v48:64-v96:128-v192:256-v256:256-v512:512-v1024:1024-v2048:2048-n32:64-S32-A5-G1-ni:7:8:9"
target triple = "amdgcn-amd-amdhsa"

@global_smem = external local_unnamed_addr addrspace(3) global [0 x i8], align 16

; Function Attrs: mustprogress norecurse nounwind willreturn
define amdgpu_kernel void @bwd_preprocess_min(ptr addrspace(1) inreg readonly captures(none) %0, ptr addrspace(1) inreg readonly captures(none) %1, ptr addrspace(1) inreg writeonly captures(none) %2, i64 inreg %3, i64 inreg %4, i64 inreg %5, i64 inreg %6, i64 inreg %7, i64 inreg %8, ptr addrspace(1) inreg readonly captures(none) %9, i32 inreg %10, i32 inreg %11, i32 inreg %12, ptr addrspace(1) inreg readnone captures(none) %13, ptr addrspace(1) inreg readnone captures(none) %14) local_unnamed_addr #0 {
  %16 = tail call i32 @llvm.amdgcn.workitem.id.x()
  %17 = tail call i32 @llvm.amdgcn.readfirstlane.i32(i32 %16)
  %18 = lshr i32 %17, 6
  %19 = and i32 %18, 3
  %20 = tail call i32 @llvm.amdgcn.workgroup.id.x()
  %21 = shl i32 %20, 7
  %22 = and i32 %16, 63
  %23 = shl nuw nsw i32 %19, 6
  %.masked = and i32 %23, 64
  %24 = or disjoint i32 %.masked, %22
  %25 = or disjoint i32 %19, %21
  %26 = or disjoint i32 %25, 4
  %27 = or disjoint i32 %25, 8
  %28 = or disjoint i32 %25, 12
  %29 = or disjoint i32 %25, 16
  %30 = or disjoint i32 %25, 20
  %31 = or disjoint i32 %25, 24
  %32 = or disjoint i32 %25, 28
  %33 = or disjoint i32 %25, 32
  %34 = or disjoint i32 %25, 36
  %35 = or disjoint i32 %25, 40
  %36 = or disjoint i32 %25, 44
  %37 = or disjoint i32 %25, 48
  %38 = or disjoint i32 %25, 52
  %39 = or disjoint i32 %25, 56
  %40 = or disjoint i32 %25, 60
  %41 = or disjoint i32 %25, 64
  %42 = or disjoint i32 %25, 68
  %43 = or disjoint i32 %25, 72
  %44 = or disjoint i32 %25, 76
  %45 = or disjoint i32 %25, 80
  %46 = or disjoint i32 %25, 84
  %47 = or disjoint i32 %25, 88
  %48 = or disjoint i32 %25, 92
  %49 = or disjoint i32 %25, 96
  %50 = or disjoint i32 %25, 100
  %51 = or disjoint i32 %25, 104
  %52 = or disjoint i32 %25, 108
  %53 = or disjoint i32 %25, 112
  %54 = or disjoint i32 %25, 116
  %55 = or disjoint i32 %25, 120
  %56 = or disjoint i32 %25, 124
  %57 = tail call i32 @llvm.amdgcn.workgroup.id.y()
  %58 = tail call i32 @llvm.amdgcn.workgroup.id.z()
  %59 = tail call dereferenceable(256) ptr addrspace(4) @llvm.amdgcn.implicitarg.ptr()
  %60 = getelementptr inbounds nuw i8, ptr addrspace(4) %59, i64 4
  %61 = load i32, ptr addrspace(4) %60, align 4, !tbaa !4
  %62 = sext i32 %58 to i64
  %63 = mul i64 %3, %62
  %64 = sext i32 %57 to i64
  %65 = mul i64 %4, %64
  %66 = getelementptr [2 x i8], ptr addrspace(1) %0, i64 %63
  %67 = getelementptr [2 x i8], ptr addrspace(1) %66, i64 %65
  %68 = sext i32 %25 to i64
  %69 = sext i32 %26 to i64
  %70 = sext i32 %27 to i64
  %71 = sext i32 %28 to i64
  %72 = sext i32 %29 to i64
  %73 = sext i32 %30 to i64
  %74 = sext i32 %31 to i64
  %75 = sext i32 %32 to i64
  %76 = sext i32 %33 to i64
  %77 = sext i32 %34 to i64
  %78 = sext i32 %35 to i64
  %79 = sext i32 %36 to i64
  %80 = sext i32 %37 to i64
  %81 = sext i32 %38 to i64
  %82 = sext i32 %39 to i64
  %83 = sext i32 %40 to i64
  %84 = sext i32 %41 to i64
  %85 = sext i32 %42 to i64
  %86 = sext i32 %43 to i64
  %87 = sext i32 %44 to i64
  %88 = sext i32 %45 to i64
  %89 = sext i32 %46 to i64
  %90 = sext i32 %47 to i64
  %91 = sext i32 %48 to i64
  %92 = sext i32 %49 to i64
  %93 = sext i32 %50 to i64
  %94 = sext i32 %51 to i64
  %95 = sext i32 %52 to i64
  %96 = sext i32 %53 to i64
  %97 = sext i32 %54 to i64
  %98 = sext i32 %55 to i64
  %99 = sext i32 %56 to i64
  %100 = mul i64 %5, %68
  %101 = mul i64 %5, %69
  %102 = mul i64 %5, %70
  %103 = mul i64 %5, %71
  %104 = mul i64 %5, %72
  %105 = mul i64 %5, %73
  %106 = mul i64 %5, %74
  %107 = mul i64 %5, %75
  %108 = mul i64 %5, %76
  %109 = mul i64 %5, %77
  %110 = mul i64 %5, %78
  %111 = mul i64 %5, %79
  %112 = mul i64 %5, %80
  %113 = mul i64 %5, %81
  %114 = mul i64 %5, %82
  %115 = mul i64 %5, %83
  %116 = mul i64 %5, %84
  %117 = mul i64 %5, %85
  %118 = mul i64 %5, %86
  %119 = mul i64 %5, %87
  %120 = mul i64 %5, %88
  %121 = mul i64 %5, %89
  %122 = mul i64 %5, %90
  %123 = mul i64 %5, %91
  %124 = mul i64 %5, %92
  %125 = mul i64 %5, %93
  %126 = mul i64 %5, %94
  %127 = mul i64 %5, %95
  %128 = mul i64 %5, %96
  %129 = mul i64 %5, %97
  %130 = mul i64 %5, %98
  %131 = mul i64 %5, %99
  %132 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %100
  %133 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %101
  %134 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %102
  %135 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %103
  %136 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %104
  %137 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %105
  %138 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %106
  %139 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %107
  %140 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %108
  %141 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %109
  %142 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %110
  %143 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %111
  %144 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %112
  %145 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %113
  %146 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %114
  %147 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %115
  %148 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %116
  %149 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %117
  %150 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %118
  %151 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %119
  %152 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %120
  %153 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %121
  %154 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %122
  %155 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %123
  %156 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %124
  %157 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %125
  %158 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %126
  %159 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %127
  %160 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %128
  %161 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %129
  %162 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %130
  %163 = getelementptr [2 x i8], ptr addrspace(1) %67, i64 %131
  %164 = shl nuw nsw i32 %22, 3
  %165 = zext nneg i32 %164 to i64
  %166 = getelementptr [2 x i8], ptr addrspace(1) %132, i64 %165
  %167 = getelementptr [2 x i8], ptr addrspace(1) %133, i64 %165
  %168 = getelementptr [2 x i8], ptr addrspace(1) %134, i64 %165
  %169 = getelementptr [2 x i8], ptr addrspace(1) %135, i64 %165
  %170 = getelementptr [2 x i8], ptr addrspace(1) %136, i64 %165
  %171 = getelementptr [2 x i8], ptr addrspace(1) %137, i64 %165
  %172 = getelementptr [2 x i8], ptr addrspace(1) %138, i64 %165
  %173 = getelementptr [2 x i8], ptr addrspace(1) %139, i64 %165
  %174 = getelementptr [2 x i8], ptr addrspace(1) %140, i64 %165
  %175 = getelementptr [2 x i8], ptr addrspace(1) %141, i64 %165
  %176 = getelementptr [2 x i8], ptr addrspace(1) %142, i64 %165
  %177 = getelementptr [2 x i8], ptr addrspace(1) %143, i64 %165
  %178 = getelementptr [2 x i8], ptr addrspace(1) %144, i64 %165
  %179 = getelementptr [2 x i8], ptr addrspace(1) %145, i64 %165
  %180 = getelementptr [2 x i8], ptr addrspace(1) %146, i64 %165
  %181 = getelementptr [2 x i8], ptr addrspace(1) %147, i64 %165
  %182 = getelementptr [2 x i8], ptr addrspace(1) %148, i64 %165
  %183 = getelementptr [2 x i8], ptr addrspace(1) %149, i64 %165
  %184 = getelementptr [2 x i8], ptr addrspace(1) %150, i64 %165
  %185 = getelementptr [2 x i8], ptr addrspace(1) %151, i64 %165
  %186 = getelementptr [2 x i8], ptr addrspace(1) %152, i64 %165
  %187 = getelementptr [2 x i8], ptr addrspace(1) %153, i64 %165
  %188 = getelementptr [2 x i8], ptr addrspace(1) %154, i64 %165
  %189 = getelementptr [2 x i8], ptr addrspace(1) %155, i64 %165
  %190 = getelementptr [2 x i8], ptr addrspace(1) %156, i64 %165
  %191 = getelementptr [2 x i8], ptr addrspace(1) %157, i64 %165
  %192 = getelementptr [2 x i8], ptr addrspace(1) %158, i64 %165
  %193 = getelementptr [2 x i8], ptr addrspace(1) %159, i64 %165
  %194 = getelementptr [2 x i8], ptr addrspace(1) %160, i64 %165
  %195 = getelementptr [2 x i8], ptr addrspace(1) %161, i64 %165
  %196 = getelementptr [2 x i8], ptr addrspace(1) %162, i64 %165
  %197 = getelementptr [2 x i8], ptr addrspace(1) %163, i64 %165
  %198 = icmp eq i32 %10, 0
  br i1 %198, label %207, label %199

199:                                              ; preds = %15
  %200 = getelementptr [4 x i8], ptr addrspace(1) %9, i64 %62
  %201 = load <1 x i32>, ptr addrspace(1) %200, align 4
  %202 = extractelement <1 x i32> %201, i64 0
  %203 = getelementptr i8, ptr addrspace(1) %200, i64 4
  %204 = load <1 x i32>, ptr addrspace(1) %203, align 4
  %205 = extractelement <1 x i32> %204, i64 0
  %206 = sub i32 %205, %202
  br label %207

207:                                              ; preds = %199, %15
  %208 = phi i32 [ %206, %199 ], [ %11, %15 ]
  %209 = mul i64 %6, %62
  %210 = mul i64 %7, %64
  %211 = getelementptr [2 x i8], ptr addrspace(1) %1, i64 %209
  %212 = getelementptr [2 x i8], ptr addrspace(1) %211, i64 %210
  %213 = mul i64 %8, %68
  %214 = mul i64 %8, %69
  %215 = mul i64 %8, %70
  %216 = mul i64 %8, %71
  %217 = mul i64 %8, %72
  %218 = mul i64 %8, %73
  %219 = mul i64 %8, %74
  %220 = mul i64 %8, %75
  %221 = mul i64 %8, %76
  %222 = mul i64 %8, %77
  %223 = mul i64 %8, %78
  %224 = mul i64 %8, %79
  %225 = mul i64 %8, %80
  %226 = mul i64 %8, %81
  %227 = mul i64 %8, %82
  %228 = mul i64 %8, %83
  %229 = mul i64 %8, %84
  %230 = mul i64 %8, %85
  %231 = mul i64 %8, %86
  %232 = mul i64 %8, %87
  %233 = mul i64 %8, %88
  %234 = mul i64 %8, %89
  %235 = mul i64 %8, %90
  %236 = mul i64 %8, %91
  %237 = mul i64 %8, %92
  %238 = mul i64 %8, %93
  %239 = mul i64 %8, %94
  %240 = mul i64 %8, %95
  %241 = mul i64 %8, %96
  %242 = mul i64 %8, %97
  %243 = mul i64 %8, %98
  %244 = mul i64 %8, %99
  %245 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %213
  %246 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %214
  %247 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %215
  %248 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %216
  %249 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %217
  %250 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %218
  %251 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %219
  %252 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %220
  %253 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %221
  %254 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %222
  %255 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %223
  %256 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %224
  %257 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %225
  %258 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %226
  %259 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %227
  %260 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %228
  %261 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %229
  %262 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %230
  %263 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %231
  %264 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %232
  %265 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %233
  %266 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %234
  %267 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %235
  %268 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %236
  %269 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %237
  %270 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %238
  %271 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %239
  %272 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %240
  %273 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %241
  %274 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %242
  %275 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %243
  %276 = getelementptr [2 x i8], ptr addrspace(1) %212, i64 %244
  %277 = getelementptr [2 x i8], ptr addrspace(1) %245, i64 %165
  %278 = getelementptr [2 x i8], ptr addrspace(1) %246, i64 %165
  %279 = getelementptr [2 x i8], ptr addrspace(1) %247, i64 %165
  %280 = getelementptr [2 x i8], ptr addrspace(1) %248, i64 %165
  %281 = getelementptr [2 x i8], ptr addrspace(1) %249, i64 %165
  %282 = getelementptr [2 x i8], ptr addrspace(1) %250, i64 %165
  %283 = getelementptr [2 x i8], ptr addrspace(1) %251, i64 %165
  %284 = getelementptr [2 x i8], ptr addrspace(1) %252, i64 %165
  %285 = getelementptr [2 x i8], ptr addrspace(1) %253, i64 %165
  %286 = getelementptr [2 x i8], ptr addrspace(1) %254, i64 %165
  %287 = getelementptr [2 x i8], ptr addrspace(1) %255, i64 %165
  %288 = getelementptr [2 x i8], ptr addrspace(1) %256, i64 %165
  %289 = getelementptr [2 x i8], ptr addrspace(1) %257, i64 %165
  %290 = getelementptr [2 x i8], ptr addrspace(1) %258, i64 %165
  %291 = getelementptr [2 x i8], ptr addrspace(1) %259, i64 %165
  %292 = getelementptr [2 x i8], ptr addrspace(1) %260, i64 %165
  %293 = getelementptr [2 x i8], ptr addrspace(1) %261, i64 %165
  %294 = getelementptr [2 x i8], ptr addrspace(1) %262, i64 %165
  %295 = getelementptr [2 x i8], ptr addrspace(1) %263, i64 %165
  %296 = getelementptr [2 x i8], ptr addrspace(1) %264, i64 %165
  %297 = getelementptr [2 x i8], ptr addrspace(1) %265, i64 %165
  %298 = getelementptr [2 x i8], ptr addrspace(1) %266, i64 %165
  %299 = getelementptr [2 x i8], ptr addrspace(1) %267, i64 %165
  %300 = getelementptr [2 x i8], ptr addrspace(1) %268, i64 %165
  %301 = getelementptr [2 x i8], ptr addrspace(1) %269, i64 %165
  %302 = getelementptr [2 x i8], ptr addrspace(1) %270, i64 %165
  %303 = getelementptr [2 x i8], ptr addrspace(1) %271, i64 %165
  %304 = getelementptr [2 x i8], ptr addrspace(1) %272, i64 %165
  %305 = getelementptr [2 x i8], ptr addrspace(1) %273, i64 %165
  %306 = getelementptr [2 x i8], ptr addrspace(1) %274, i64 %165
  %307 = getelementptr [2 x i8], ptr addrspace(1) %275, i64 %165
  %308 = getelementptr [2 x i8], ptr addrspace(1) %276, i64 %165
  %309 = icmp slt i32 %25, %208
  %310 = icmp slt i32 %26, %208
  %311 = icmp slt i32 %27, %208
  %312 = icmp slt i32 %28, %208
  %313 = icmp slt i32 %29, %208
  %314 = icmp slt i32 %30, %208
  %315 = icmp slt i32 %31, %208
  %316 = icmp slt i32 %32, %208
  %317 = icmp slt i32 %33, %208
  %318 = icmp slt i32 %34, %208
  %319 = icmp slt i32 %35, %208
  %320 = icmp slt i32 %36, %208
  %321 = icmp slt i32 %37, %208
  %322 = icmp slt i32 %38, %208
  %323 = icmp slt i32 %39, %208
  %324 = icmp slt i32 %40, %208
  %325 = icmp slt i32 %41, %208
  %326 = icmp slt i32 %42, %208
  %327 = icmp slt i32 %43, %208
  %328 = icmp slt i32 %44, %208
  %329 = icmp slt i32 %45, %208
  %330 = icmp slt i32 %46, %208
  %331 = icmp slt i32 %47, %208
  %332 = icmp slt i32 %48, %208
  %333 = icmp slt i32 %49, %208
  %334 = icmp slt i32 %50, %208
  %335 = icmp slt i32 %51, %208
  %336 = icmp slt i32 %52, %208
  %337 = icmp slt i32 %53, %208
  %338 = icmp slt i32 %54, %208
  %339 = icmp slt i32 %55, %208
  %340 = icmp slt i32 %56, %208
  br i1 %309, label %341, label %343

341:                                              ; preds = %207
  %342 = load <8 x half>, ptr addrspace(1) %166, align 16
  br label %343

343:                                              ; preds = %341, %207
  %344 = phi <8 x half> [ %342, %341 ], [ zeroinitializer, %207 ]
  br i1 %310, label %345, label %347

345:                                              ; preds = %343
  %346 = load <8 x half>, ptr addrspace(1) %167, align 16
  br label %347

347:                                              ; preds = %345, %343
  %348 = phi <8 x half> [ %346, %345 ], [ zeroinitializer, %343 ]
  br i1 %311, label %349, label %351

349:                                              ; preds = %347
  %350 = load <8 x half>, ptr addrspace(1) %168, align 16
  br label %351

351:                                              ; preds = %349, %347
  %352 = phi <8 x half> [ %350, %349 ], [ zeroinitializer, %347 ]
  br i1 %312, label %353, label %355

353:                                              ; preds = %351
  %354 = load <8 x half>, ptr addrspace(1) %169, align 16
  br label %355

355:                                              ; preds = %353, %351
  %356 = phi <8 x half> [ %354, %353 ], [ zeroinitializer, %351 ]
  br i1 %313, label %357, label %359

357:                                              ; preds = %355
  %358 = load <8 x half>, ptr addrspace(1) %170, align 16
  br label %359

359:                                              ; preds = %357, %355
  %360 = phi <8 x half> [ %358, %357 ], [ zeroinitializer, %355 ]
  br i1 %314, label %361, label %363

361:                                              ; preds = %359
  %362 = load <8 x half>, ptr addrspace(1) %171, align 16
  br label %363

363:                                              ; preds = %361, %359
  %364 = phi <8 x half> [ %362, %361 ], [ zeroinitializer, %359 ]
  br i1 %315, label %365, label %367

365:                                              ; preds = %363
  %366 = load <8 x half>, ptr addrspace(1) %172, align 16
  br label %367

367:                                              ; preds = %365, %363
  %368 = phi <8 x half> [ %366, %365 ], [ zeroinitializer, %363 ]
  br i1 %316, label %369, label %371

369:                                              ; preds = %367
  %370 = load <8 x half>, ptr addrspace(1) %173, align 16
  br label %371

371:                                              ; preds = %369, %367
  %372 = phi <8 x half> [ %370, %369 ], [ zeroinitializer, %367 ]
  br i1 %317, label %373, label %375

373:                                              ; preds = %371
  %374 = load <8 x half>, ptr addrspace(1) %174, align 16
  br label %375

375:                                              ; preds = %373, %371
  %376 = phi <8 x half> [ %374, %373 ], [ zeroinitializer, %371 ]
  br i1 %318, label %377, label %379

377:                                              ; preds = %375
  %378 = load <8 x half>, ptr addrspace(1) %175, align 16
  br label %379

379:                                              ; preds = %377, %375
  %380 = phi <8 x half> [ %378, %377 ], [ zeroinitializer, %375 ]
  br i1 %319, label %381, label %383

381:                                              ; preds = %379
  %382 = load <8 x half>, ptr addrspace(1) %176, align 16
  br label %383

383:                                              ; preds = %381, %379
  %384 = phi <8 x half> [ %382, %381 ], [ zeroinitializer, %379 ]
  br i1 %320, label %385, label %387

385:                                              ; preds = %383
  %386 = load <8 x half>, ptr addrspace(1) %177, align 16
  br label %387

387:                                              ; preds = %385, %383
  %388 = phi <8 x half> [ %386, %385 ], [ zeroinitializer, %383 ]
  br i1 %321, label %389, label %391

389:                                              ; preds = %387
  %390 = load <8 x half>, ptr addrspace(1) %178, align 16
  br label %391

391:                                              ; preds = %389, %387
  %392 = phi <8 x half> [ %390, %389 ], [ zeroinitializer, %387 ]
  br i1 %322, label %393, label %395

393:                                              ; preds = %391
  %394 = load <8 x half>, ptr addrspace(1) %179, align 16
  br label %395

395:                                              ; preds = %393, %391
  %396 = phi <8 x half> [ %394, %393 ], [ zeroinitializer, %391 ]
  br i1 %323, label %397, label %399

397:                                              ; preds = %395
  %398 = load <8 x half>, ptr addrspace(1) %180, align 16
  br label %399

399:                                              ; preds = %397, %395
  %400 = phi <8 x half> [ %398, %397 ], [ zeroinitializer, %395 ]
  br i1 %324, label %401, label %403

401:                                              ; preds = %399
  %402 = load <8 x half>, ptr addrspace(1) %181, align 16
  br label %403

403:                                              ; preds = %401, %399
  %404 = phi <8 x half> [ %402, %401 ], [ zeroinitializer, %399 ]
  br i1 %325, label %405, label %407

405:                                              ; preds = %403
  %406 = load <8 x half>, ptr addrspace(1) %182, align 16
  br label %407

407:                                              ; preds = %405, %403
  %408 = phi <8 x half> [ %406, %405 ], [ zeroinitializer, %403 ]
  br i1 %326, label %409, label %411

409:                                              ; preds = %407
  %410 = load <8 x half>, ptr addrspace(1) %183, align 16
  br label %411

411:                                              ; preds = %409, %407
  %412 = phi <8 x half> [ %410, %409 ], [ zeroinitializer, %407 ]
  br i1 %327, label %413, label %415

413:                                              ; preds = %411
  %414 = load <8 x half>, ptr addrspace(1) %184, align 16
  br label %415

415:                                              ; preds = %413, %411
  %416 = phi <8 x half> [ %414, %413 ], [ zeroinitializer, %411 ]
  br i1 %328, label %417, label %419

417:                                              ; preds = %415
  %418 = load <8 x half>, ptr addrspace(1) %185, align 16
  br label %419

419:                                              ; preds = %417, %415
  %420 = phi <8 x half> [ %418, %417 ], [ zeroinitializer, %415 ]
  br i1 %329, label %421, label %423

421:                                              ; preds = %419
  %422 = load <8 x half>, ptr addrspace(1) %186, align 16
  br label %423

423:                                              ; preds = %421, %419
  %424 = phi <8 x half> [ %422, %421 ], [ zeroinitializer, %419 ]
  br i1 %330, label %425, label %427

425:                                              ; preds = %423
  %426 = load <8 x half>, ptr addrspace(1) %187, align 16
  br label %427

427:                                              ; preds = %425, %423
  %428 = phi <8 x half> [ %426, %425 ], [ zeroinitializer, %423 ]
  br i1 %331, label %429, label %431

429:                                              ; preds = %427
  %430 = load <8 x half>, ptr addrspace(1) %188, align 16
  br label %431

431:                                              ; preds = %429, %427
  %432 = phi <8 x half> [ %430, %429 ], [ zeroinitializer, %427 ]
  br i1 %332, label %433, label %435

433:                                              ; preds = %431
  %434 = load <8 x half>, ptr addrspace(1) %189, align 16
  br label %435

435:                                              ; preds = %433, %431
  %436 = phi <8 x half> [ %434, %433 ], [ zeroinitializer, %431 ]
  br i1 %333, label %437, label %439

437:                                              ; preds = %435
  %438 = load <8 x half>, ptr addrspace(1) %190, align 16
  br label %439

439:                                              ; preds = %437, %435
  %440 = phi <8 x half> [ %438, %437 ], [ zeroinitializer, %435 ]
  br i1 %334, label %441, label %443

441:                                              ; preds = %439
  %442 = load <8 x half>, ptr addrspace(1) %191, align 16
  br label %443

443:                                              ; preds = %441, %439
  %444 = phi <8 x half> [ %442, %441 ], [ zeroinitializer, %439 ]
  br i1 %335, label %445, label %447

445:                                              ; preds = %443
  %446 = load <8 x half>, ptr addrspace(1) %192, align 16
  br label %447

447:                                              ; preds = %445, %443
  %448 = phi <8 x half> [ %446, %445 ], [ zeroinitializer, %443 ]
  br i1 %336, label %449, label %451

449:                                              ; preds = %447
  %450 = load <8 x half>, ptr addrspace(1) %193, align 16
  br label %451

451:                                              ; preds = %449, %447
  %452 = phi <8 x half> [ %450, %449 ], [ zeroinitializer, %447 ]
  br i1 %337, label %453, label %455

453:                                              ; preds = %451
  %454 = load <8 x half>, ptr addrspace(1) %194, align 16
  br label %455

455:                                              ; preds = %453, %451
  %456 = phi <8 x half> [ %454, %453 ], [ zeroinitializer, %451 ]
  br i1 %338, label %457, label %459

457:                                              ; preds = %455
  %458 = load <8 x half>, ptr addrspace(1) %195, align 16
  br label %459

459:                                              ; preds = %457, %455
  %460 = phi <8 x half> [ %458, %457 ], [ zeroinitializer, %455 ]
  br i1 %339, label %461, label %463

461:                                              ; preds = %459
  %462 = load <8 x half>, ptr addrspace(1) %196, align 16
  br label %463

463:                                              ; preds = %461, %459
  %464 = phi <8 x half> [ %462, %461 ], [ zeroinitializer, %459 ]
  br i1 %340, label %465, label %467

465:                                              ; preds = %463
  %466 = load <8 x half>, ptr addrspace(1) %197, align 16
  br label %467

467:                                              ; preds = %465, %463
  %468 = phi <8 x half> [ %466, %465 ], [ zeroinitializer, %463 ]
  %469 = shufflevector <8 x half> %344, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %470 = fpext <2 x half> %469 to <2 x float>
  %471 = shufflevector <8 x half> %344, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %472 = fpext <2 x half> %471 to <2 x float>
  %473 = shufflevector <8 x half> %344, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %474 = fpext <2 x half> %473 to <2 x float>
  %475 = shufflevector <8 x half> %344, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %476 = fpext <2 x half> %475 to <2 x float>
  %477 = shufflevector <8 x half> %348, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %478 = fpext <2 x half> %477 to <2 x float>
  %479 = shufflevector <8 x half> %348, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %480 = fpext <2 x half> %479 to <2 x float>
  %481 = shufflevector <8 x half> %348, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %482 = fpext <2 x half> %481 to <2 x float>
  %483 = shufflevector <8 x half> %348, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %484 = fpext <2 x half> %483 to <2 x float>
  %485 = shufflevector <8 x half> %352, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %486 = fpext <2 x half> %485 to <2 x float>
  %487 = shufflevector <8 x half> %352, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %488 = fpext <2 x half> %487 to <2 x float>
  %489 = shufflevector <8 x half> %352, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %490 = fpext <2 x half> %489 to <2 x float>
  %491 = shufflevector <8 x half> %352, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %492 = fpext <2 x half> %491 to <2 x float>
  %493 = shufflevector <8 x half> %356, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %494 = fpext <2 x half> %493 to <2 x float>
  %495 = shufflevector <8 x half> %356, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %496 = fpext <2 x half> %495 to <2 x float>
  %497 = shufflevector <8 x half> %356, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %498 = fpext <2 x half> %497 to <2 x float>
  %499 = shufflevector <8 x half> %356, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %500 = fpext <2 x half> %499 to <2 x float>
  %501 = shufflevector <8 x half> %360, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %502 = fpext <2 x half> %501 to <2 x float>
  %503 = shufflevector <8 x half> %360, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %504 = fpext <2 x half> %503 to <2 x float>
  %505 = shufflevector <8 x half> %360, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %506 = fpext <2 x half> %505 to <2 x float>
  %507 = shufflevector <8 x half> %360, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %508 = fpext <2 x half> %507 to <2 x float>
  %509 = shufflevector <8 x half> %364, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %510 = fpext <2 x half> %509 to <2 x float>
  %511 = shufflevector <8 x half> %364, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %512 = fpext <2 x half> %511 to <2 x float>
  %513 = shufflevector <8 x half> %364, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %514 = fpext <2 x half> %513 to <2 x float>
  %515 = shufflevector <8 x half> %364, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %516 = fpext <2 x half> %515 to <2 x float>
  %517 = shufflevector <8 x half> %368, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %518 = fpext <2 x half> %517 to <2 x float>
  %519 = shufflevector <8 x half> %368, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %520 = fpext <2 x half> %519 to <2 x float>
  %521 = shufflevector <8 x half> %368, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %522 = fpext <2 x half> %521 to <2 x float>
  %523 = shufflevector <8 x half> %368, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %524 = fpext <2 x half> %523 to <2 x float>
  %525 = shufflevector <8 x half> %372, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %526 = fpext <2 x half> %525 to <2 x float>
  %527 = shufflevector <8 x half> %372, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %528 = fpext <2 x half> %527 to <2 x float>
  %529 = shufflevector <8 x half> %372, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %530 = fpext <2 x half> %529 to <2 x float>
  %531 = shufflevector <8 x half> %372, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %532 = fpext <2 x half> %531 to <2 x float>
  %533 = shufflevector <8 x half> %376, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %534 = fpext <2 x half> %533 to <2 x float>
  %535 = shufflevector <8 x half> %376, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %536 = fpext <2 x half> %535 to <2 x float>
  %537 = shufflevector <8 x half> %376, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %538 = fpext <2 x half> %537 to <2 x float>
  %539 = shufflevector <8 x half> %376, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %540 = fpext <2 x half> %539 to <2 x float>
  %541 = shufflevector <8 x half> %380, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %542 = fpext <2 x half> %541 to <2 x float>
  %543 = shufflevector <8 x half> %380, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %544 = fpext <2 x half> %543 to <2 x float>
  %545 = shufflevector <8 x half> %380, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %546 = fpext <2 x half> %545 to <2 x float>
  %547 = shufflevector <8 x half> %380, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %548 = fpext <2 x half> %547 to <2 x float>
  %549 = shufflevector <8 x half> %384, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %550 = fpext <2 x half> %549 to <2 x float>
  %551 = shufflevector <8 x half> %384, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %552 = fpext <2 x half> %551 to <2 x float>
  %553 = shufflevector <8 x half> %384, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %554 = fpext <2 x half> %553 to <2 x float>
  %555 = shufflevector <8 x half> %384, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %556 = fpext <2 x half> %555 to <2 x float>
  %557 = shufflevector <8 x half> %388, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %558 = fpext <2 x half> %557 to <2 x float>
  %559 = shufflevector <8 x half> %388, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %560 = fpext <2 x half> %559 to <2 x float>
  %561 = shufflevector <8 x half> %388, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %562 = fpext <2 x half> %561 to <2 x float>
  %563 = shufflevector <8 x half> %388, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %564 = fpext <2 x half> %563 to <2 x float>
  %565 = shufflevector <8 x half> %392, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %566 = fpext <2 x half> %565 to <2 x float>
  %567 = shufflevector <8 x half> %392, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %568 = fpext <2 x half> %567 to <2 x float>
  %569 = shufflevector <8 x half> %392, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %570 = fpext <2 x half> %569 to <2 x float>
  %571 = shufflevector <8 x half> %392, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %572 = fpext <2 x half> %571 to <2 x float>
  %573 = shufflevector <8 x half> %396, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %574 = fpext <2 x half> %573 to <2 x float>
  %575 = shufflevector <8 x half> %396, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %576 = fpext <2 x half> %575 to <2 x float>
  %577 = shufflevector <8 x half> %396, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %578 = fpext <2 x half> %577 to <2 x float>
  %579 = shufflevector <8 x half> %396, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %580 = fpext <2 x half> %579 to <2 x float>
  %581 = shufflevector <8 x half> %400, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %582 = fpext <2 x half> %581 to <2 x float>
  %583 = shufflevector <8 x half> %400, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %584 = fpext <2 x half> %583 to <2 x float>
  %585 = shufflevector <8 x half> %400, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %586 = fpext <2 x half> %585 to <2 x float>
  %587 = shufflevector <8 x half> %400, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %588 = fpext <2 x half> %587 to <2 x float>
  %589 = shufflevector <8 x half> %404, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %590 = fpext <2 x half> %589 to <2 x float>
  %591 = shufflevector <8 x half> %404, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %592 = fpext <2 x half> %591 to <2 x float>
  %593 = shufflevector <8 x half> %404, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %594 = fpext <2 x half> %593 to <2 x float>
  %595 = shufflevector <8 x half> %404, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %596 = fpext <2 x half> %595 to <2 x float>
  %597 = shufflevector <8 x half> %408, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %598 = fpext <2 x half> %597 to <2 x float>
  %599 = shufflevector <8 x half> %408, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %600 = fpext <2 x half> %599 to <2 x float>
  %601 = shufflevector <8 x half> %408, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %602 = fpext <2 x half> %601 to <2 x float>
  %603 = shufflevector <8 x half> %408, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %604 = fpext <2 x half> %603 to <2 x float>
  %605 = shufflevector <8 x half> %412, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %606 = fpext <2 x half> %605 to <2 x float>
  %607 = shufflevector <8 x half> %412, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %608 = fpext <2 x half> %607 to <2 x float>
  %609 = shufflevector <8 x half> %412, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %610 = fpext <2 x half> %609 to <2 x float>
  %611 = shufflevector <8 x half> %412, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %612 = fpext <2 x half> %611 to <2 x float>
  %613 = shufflevector <8 x half> %416, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %614 = fpext <2 x half> %613 to <2 x float>
  %615 = shufflevector <8 x half> %416, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %616 = fpext <2 x half> %615 to <2 x float>
  %617 = shufflevector <8 x half> %416, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %618 = fpext <2 x half> %617 to <2 x float>
  %619 = shufflevector <8 x half> %416, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %620 = fpext <2 x half> %619 to <2 x float>
  %621 = shufflevector <8 x half> %420, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %622 = fpext <2 x half> %621 to <2 x float>
  %623 = shufflevector <8 x half> %420, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %624 = fpext <2 x half> %623 to <2 x float>
  %625 = shufflevector <8 x half> %420, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %626 = fpext <2 x half> %625 to <2 x float>
  %627 = shufflevector <8 x half> %420, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %628 = fpext <2 x half> %627 to <2 x float>
  %629 = shufflevector <8 x half> %424, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %630 = fpext <2 x half> %629 to <2 x float>
  %631 = shufflevector <8 x half> %424, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %632 = fpext <2 x half> %631 to <2 x float>
  %633 = shufflevector <8 x half> %424, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %634 = fpext <2 x half> %633 to <2 x float>
  %635 = shufflevector <8 x half> %424, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %636 = fpext <2 x half> %635 to <2 x float>
  %637 = shufflevector <8 x half> %428, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %638 = fpext <2 x half> %637 to <2 x float>
  %639 = shufflevector <8 x half> %428, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %640 = fpext <2 x half> %639 to <2 x float>
  %641 = shufflevector <8 x half> %428, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %642 = fpext <2 x half> %641 to <2 x float>
  %643 = shufflevector <8 x half> %428, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %644 = fpext <2 x half> %643 to <2 x float>
  %645 = shufflevector <8 x half> %432, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %646 = fpext <2 x half> %645 to <2 x float>
  %647 = shufflevector <8 x half> %432, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %648 = fpext <2 x half> %647 to <2 x float>
  %649 = shufflevector <8 x half> %432, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %650 = fpext <2 x half> %649 to <2 x float>
  %651 = shufflevector <8 x half> %432, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %652 = fpext <2 x half> %651 to <2 x float>
  %653 = shufflevector <8 x half> %436, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %654 = fpext <2 x half> %653 to <2 x float>
  %655 = shufflevector <8 x half> %436, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %656 = fpext <2 x half> %655 to <2 x float>
  %657 = shufflevector <8 x half> %436, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %658 = fpext <2 x half> %657 to <2 x float>
  %659 = shufflevector <8 x half> %436, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %660 = fpext <2 x half> %659 to <2 x float>
  %661 = shufflevector <8 x half> %440, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %662 = fpext <2 x half> %661 to <2 x float>
  %663 = shufflevector <8 x half> %440, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %664 = fpext <2 x half> %663 to <2 x float>
  %665 = shufflevector <8 x half> %440, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %666 = fpext <2 x half> %665 to <2 x float>
  %667 = shufflevector <8 x half> %440, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %668 = fpext <2 x half> %667 to <2 x float>
  %669 = shufflevector <8 x half> %444, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %670 = fpext <2 x half> %669 to <2 x float>
  %671 = shufflevector <8 x half> %444, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %672 = fpext <2 x half> %671 to <2 x float>
  %673 = shufflevector <8 x half> %444, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %674 = fpext <2 x half> %673 to <2 x float>
  %675 = shufflevector <8 x half> %444, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %676 = fpext <2 x half> %675 to <2 x float>
  %677 = shufflevector <8 x half> %448, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %678 = fpext <2 x half> %677 to <2 x float>
  %679 = shufflevector <8 x half> %448, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %680 = fpext <2 x half> %679 to <2 x float>
  %681 = shufflevector <8 x half> %448, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %682 = fpext <2 x half> %681 to <2 x float>
  %683 = shufflevector <8 x half> %448, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %684 = fpext <2 x half> %683 to <2 x float>
  %685 = shufflevector <8 x half> %452, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %686 = fpext <2 x half> %685 to <2 x float>
  %687 = shufflevector <8 x half> %452, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %688 = fpext <2 x half> %687 to <2 x float>
  %689 = shufflevector <8 x half> %452, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %690 = fpext <2 x half> %689 to <2 x float>
  %691 = shufflevector <8 x half> %452, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %692 = fpext <2 x half> %691 to <2 x float>
  %693 = shufflevector <8 x half> %456, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %694 = fpext <2 x half> %693 to <2 x float>
  %695 = shufflevector <8 x half> %456, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %696 = fpext <2 x half> %695 to <2 x float>
  %697 = shufflevector <8 x half> %456, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %698 = fpext <2 x half> %697 to <2 x float>
  %699 = shufflevector <8 x half> %456, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %700 = fpext <2 x half> %699 to <2 x float>
  %701 = shufflevector <8 x half> %460, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %702 = fpext <2 x half> %701 to <2 x float>
  %703 = shufflevector <8 x half> %460, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %704 = fpext <2 x half> %703 to <2 x float>
  %705 = shufflevector <8 x half> %460, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %706 = fpext <2 x half> %705 to <2 x float>
  %707 = shufflevector <8 x half> %460, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %708 = fpext <2 x half> %707 to <2 x float>
  %709 = shufflevector <8 x half> %464, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %710 = fpext <2 x half> %709 to <2 x float>
  %711 = shufflevector <8 x half> %464, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %712 = fpext <2 x half> %711 to <2 x float>
  %713 = shufflevector <8 x half> %464, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %714 = fpext <2 x half> %713 to <2 x float>
  %715 = shufflevector <8 x half> %464, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %716 = fpext <2 x half> %715 to <2 x float>
  %717 = shufflevector <8 x half> %468, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %718 = fpext <2 x half> %717 to <2 x float>
  %719 = shufflevector <8 x half> %468, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %720 = fpext <2 x half> %719 to <2 x float>
  %721 = shufflevector <8 x half> %468, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %722 = fpext <2 x half> %721 to <2 x float>
  %723 = shufflevector <8 x half> %468, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %724 = fpext <2 x half> %723 to <2 x float>
  br i1 %309, label %725, label %727

725:                                              ; preds = %467
  %726 = load <8 x half>, ptr addrspace(1) %277, align 16
  br label %727

727:                                              ; preds = %725, %467
  %728 = phi <8 x half> [ %726, %725 ], [ zeroinitializer, %467 ]
  br i1 %310, label %729, label %731

729:                                              ; preds = %727
  %730 = load <8 x half>, ptr addrspace(1) %278, align 16
  br label %731

731:                                              ; preds = %729, %727
  %732 = phi <8 x half> [ %730, %729 ], [ zeroinitializer, %727 ]
  br i1 %311, label %733, label %735

733:                                              ; preds = %731
  %734 = load <8 x half>, ptr addrspace(1) %279, align 16
  br label %735

735:                                              ; preds = %733, %731
  %736 = phi <8 x half> [ %734, %733 ], [ zeroinitializer, %731 ]
  br i1 %312, label %737, label %739

737:                                              ; preds = %735
  %738 = load <8 x half>, ptr addrspace(1) %280, align 16
  br label %739

739:                                              ; preds = %737, %735
  %740 = phi <8 x half> [ %738, %737 ], [ zeroinitializer, %735 ]
  br i1 %313, label %741, label %743

741:                                              ; preds = %739
  %742 = load <8 x half>, ptr addrspace(1) %281, align 16
  br label %743

743:                                              ; preds = %741, %739
  %744 = phi <8 x half> [ %742, %741 ], [ zeroinitializer, %739 ]
  br i1 %314, label %745, label %747

745:                                              ; preds = %743
  %746 = load <8 x half>, ptr addrspace(1) %282, align 16
  br label %747

747:                                              ; preds = %745, %743
  %748 = phi <8 x half> [ %746, %745 ], [ zeroinitializer, %743 ]
  br i1 %315, label %749, label %751

749:                                              ; preds = %747
  %750 = load <8 x half>, ptr addrspace(1) %283, align 16
  br label %751

751:                                              ; preds = %749, %747
  %752 = phi <8 x half> [ %750, %749 ], [ zeroinitializer, %747 ]
  br i1 %316, label %753, label %755

753:                                              ; preds = %751
  %754 = load <8 x half>, ptr addrspace(1) %284, align 16
  br label %755

755:                                              ; preds = %753, %751
  %756 = phi <8 x half> [ %754, %753 ], [ zeroinitializer, %751 ]
  br i1 %317, label %757, label %759

757:                                              ; preds = %755
  %758 = load <8 x half>, ptr addrspace(1) %285, align 16
  br label %759

759:                                              ; preds = %757, %755
  %760 = phi <8 x half> [ %758, %757 ], [ zeroinitializer, %755 ]
  br i1 %318, label %761, label %763

761:                                              ; preds = %759
  %762 = load <8 x half>, ptr addrspace(1) %286, align 16
  br label %763

763:                                              ; preds = %761, %759
  %764 = phi <8 x half> [ %762, %761 ], [ zeroinitializer, %759 ]
  br i1 %319, label %765, label %767

765:                                              ; preds = %763
  %766 = load <8 x half>, ptr addrspace(1) %287, align 16
  br label %767

767:                                              ; preds = %765, %763
  %768 = phi <8 x half> [ %766, %765 ], [ zeroinitializer, %763 ]
  br i1 %320, label %769, label %771

769:                                              ; preds = %767
  %770 = load <8 x half>, ptr addrspace(1) %288, align 16
  br label %771

771:                                              ; preds = %769, %767
  %772 = phi <8 x half> [ %770, %769 ], [ zeroinitializer, %767 ]
  br i1 %321, label %773, label %775

773:                                              ; preds = %771
  %774 = load <8 x half>, ptr addrspace(1) %289, align 16
  br label %775

775:                                              ; preds = %773, %771
  %776 = phi <8 x half> [ %774, %773 ], [ zeroinitializer, %771 ]
  br i1 %322, label %777, label %779

777:                                              ; preds = %775
  %778 = load <8 x half>, ptr addrspace(1) %290, align 16
  br label %779

779:                                              ; preds = %777, %775
  %780 = phi <8 x half> [ %778, %777 ], [ zeroinitializer, %775 ]
  br i1 %323, label %781, label %783

781:                                              ; preds = %779
  %782 = load <8 x half>, ptr addrspace(1) %291, align 16
  br label %783

783:                                              ; preds = %781, %779
  %784 = phi <8 x half> [ %782, %781 ], [ zeroinitializer, %779 ]
  br i1 %324, label %785, label %787

785:                                              ; preds = %783
  %786 = load <8 x half>, ptr addrspace(1) %292, align 16
  br label %787

787:                                              ; preds = %785, %783
  %788 = phi <8 x half> [ %786, %785 ], [ zeroinitializer, %783 ]
  br i1 %325, label %789, label %791

789:                                              ; preds = %787
  %790 = load <8 x half>, ptr addrspace(1) %293, align 16
  br label %791

791:                                              ; preds = %789, %787
  %792 = phi <8 x half> [ %790, %789 ], [ zeroinitializer, %787 ]
  br i1 %326, label %793, label %795

793:                                              ; preds = %791
  %794 = load <8 x half>, ptr addrspace(1) %294, align 16
  br label %795

795:                                              ; preds = %793, %791
  %796 = phi <8 x half> [ %794, %793 ], [ zeroinitializer, %791 ]
  br i1 %327, label %797, label %799

797:                                              ; preds = %795
  %798 = load <8 x half>, ptr addrspace(1) %295, align 16
  br label %799

799:                                              ; preds = %797, %795
  %800 = phi <8 x half> [ %798, %797 ], [ zeroinitializer, %795 ]
  br i1 %328, label %801, label %803

801:                                              ; preds = %799
  %802 = load <8 x half>, ptr addrspace(1) %296, align 16
  br label %803

803:                                              ; preds = %801, %799
  %804 = phi <8 x half> [ %802, %801 ], [ zeroinitializer, %799 ]
  br i1 %329, label %805, label %807

805:                                              ; preds = %803
  %806 = load <8 x half>, ptr addrspace(1) %297, align 16
  br label %807

807:                                              ; preds = %805, %803
  %808 = phi <8 x half> [ %806, %805 ], [ zeroinitializer, %803 ]
  br i1 %330, label %809, label %811

809:                                              ; preds = %807
  %810 = load <8 x half>, ptr addrspace(1) %298, align 16
  br label %811

811:                                              ; preds = %809, %807
  %812 = phi <8 x half> [ %810, %809 ], [ zeroinitializer, %807 ]
  br i1 %331, label %813, label %815

813:                                              ; preds = %811
  %814 = load <8 x half>, ptr addrspace(1) %299, align 16
  br label %815

815:                                              ; preds = %813, %811
  %816 = phi <8 x half> [ %814, %813 ], [ zeroinitializer, %811 ]
  br i1 %332, label %817, label %819

817:                                              ; preds = %815
  %818 = load <8 x half>, ptr addrspace(1) %300, align 16
  br label %819

819:                                              ; preds = %817, %815
  %820 = phi <8 x half> [ %818, %817 ], [ zeroinitializer, %815 ]
  br i1 %333, label %821, label %823

821:                                              ; preds = %819
  %822 = load <8 x half>, ptr addrspace(1) %301, align 16
  br label %823

823:                                              ; preds = %821, %819
  %824 = phi <8 x half> [ %822, %821 ], [ zeroinitializer, %819 ]
  br i1 %334, label %825, label %827

825:                                              ; preds = %823
  %826 = load <8 x half>, ptr addrspace(1) %302, align 16
  br label %827

827:                                              ; preds = %825, %823
  %828 = phi <8 x half> [ %826, %825 ], [ zeroinitializer, %823 ]
  br i1 %335, label %829, label %831

829:                                              ; preds = %827
  %830 = load <8 x half>, ptr addrspace(1) %303, align 16
  br label %831

831:                                              ; preds = %829, %827
  %832 = phi <8 x half> [ %830, %829 ], [ zeroinitializer, %827 ]
  br i1 %336, label %833, label %835

833:                                              ; preds = %831
  %834 = load <8 x half>, ptr addrspace(1) %304, align 16
  br label %835

835:                                              ; preds = %833, %831
  %836 = phi <8 x half> [ %834, %833 ], [ zeroinitializer, %831 ]
  br i1 %337, label %837, label %839

837:                                              ; preds = %835
  %838 = load <8 x half>, ptr addrspace(1) %305, align 16
  br label %839

839:                                              ; preds = %837, %835
  %840 = phi <8 x half> [ %838, %837 ], [ zeroinitializer, %835 ]
  br i1 %338, label %841, label %843

841:                                              ; preds = %839
  %842 = load <8 x half>, ptr addrspace(1) %306, align 16
  br label %843

843:                                              ; preds = %841, %839
  %844 = phi <8 x half> [ %842, %841 ], [ zeroinitializer, %839 ]
  br i1 %339, label %845, label %847

845:                                              ; preds = %843
  %846 = load <8 x half>, ptr addrspace(1) %307, align 16
  br label %847

847:                                              ; preds = %845, %843
  %848 = phi <8 x half> [ %846, %845 ], [ zeroinitializer, %843 ]
  br i1 %340, label %849, label %851

849:                                              ; preds = %847
  %850 = load <8 x half>, ptr addrspace(1) %308, align 16
  br label %851

851:                                              ; preds = %849, %847
  %852 = phi <8 x half> [ %850, %849 ], [ zeroinitializer, %847 ]
  %853 = shufflevector <8 x half> %728, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %854 = fpext <2 x half> %853 to <2 x float>
  %855 = shufflevector <8 x half> %728, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %856 = fpext <2 x half> %855 to <2 x float>
  %857 = shufflevector <8 x half> %728, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %858 = fpext <2 x half> %857 to <2 x float>
  %859 = shufflevector <8 x half> %728, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %860 = fpext <2 x half> %859 to <2 x float>
  %861 = shufflevector <8 x half> %732, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %862 = fpext <2 x half> %861 to <2 x float>
  %863 = shufflevector <8 x half> %732, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %864 = fpext <2 x half> %863 to <2 x float>
  %865 = shufflevector <8 x half> %732, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %866 = fpext <2 x half> %865 to <2 x float>
  %867 = shufflevector <8 x half> %732, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %868 = fpext <2 x half> %867 to <2 x float>
  %869 = shufflevector <8 x half> %736, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %870 = fpext <2 x half> %869 to <2 x float>
  %871 = shufflevector <8 x half> %736, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %872 = fpext <2 x half> %871 to <2 x float>
  %873 = shufflevector <8 x half> %736, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %874 = fpext <2 x half> %873 to <2 x float>
  %875 = shufflevector <8 x half> %736, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %876 = fpext <2 x half> %875 to <2 x float>
  %877 = shufflevector <8 x half> %740, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %878 = fpext <2 x half> %877 to <2 x float>
  %879 = shufflevector <8 x half> %740, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %880 = fpext <2 x half> %879 to <2 x float>
  %881 = shufflevector <8 x half> %740, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %882 = fpext <2 x half> %881 to <2 x float>
  %883 = shufflevector <8 x half> %740, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %884 = fpext <2 x half> %883 to <2 x float>
  %885 = shufflevector <8 x half> %744, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %886 = fpext <2 x half> %885 to <2 x float>
  %887 = shufflevector <8 x half> %744, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %888 = fpext <2 x half> %887 to <2 x float>
  %889 = shufflevector <8 x half> %744, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %890 = fpext <2 x half> %889 to <2 x float>
  %891 = shufflevector <8 x half> %744, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %892 = fpext <2 x half> %891 to <2 x float>
  %893 = shufflevector <8 x half> %748, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %894 = fpext <2 x half> %893 to <2 x float>
  %895 = shufflevector <8 x half> %748, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %896 = fpext <2 x half> %895 to <2 x float>
  %897 = shufflevector <8 x half> %748, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %898 = fpext <2 x half> %897 to <2 x float>
  %899 = shufflevector <8 x half> %748, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %900 = fpext <2 x half> %899 to <2 x float>
  %901 = shufflevector <8 x half> %752, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %902 = fpext <2 x half> %901 to <2 x float>
  %903 = shufflevector <8 x half> %752, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %904 = fpext <2 x half> %903 to <2 x float>
  %905 = shufflevector <8 x half> %752, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %906 = fpext <2 x half> %905 to <2 x float>
  %907 = shufflevector <8 x half> %752, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %908 = fpext <2 x half> %907 to <2 x float>
  %909 = shufflevector <8 x half> %756, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %910 = fpext <2 x half> %909 to <2 x float>
  %911 = shufflevector <8 x half> %756, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %912 = fpext <2 x half> %911 to <2 x float>
  %913 = shufflevector <8 x half> %756, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %914 = fpext <2 x half> %913 to <2 x float>
  %915 = shufflevector <8 x half> %756, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %916 = fpext <2 x half> %915 to <2 x float>
  %917 = shufflevector <8 x half> %760, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %918 = fpext <2 x half> %917 to <2 x float>
  %919 = shufflevector <8 x half> %760, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %920 = fpext <2 x half> %919 to <2 x float>
  %921 = shufflevector <8 x half> %760, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %922 = fpext <2 x half> %921 to <2 x float>
  %923 = shufflevector <8 x half> %760, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %924 = fpext <2 x half> %923 to <2 x float>
  %925 = shufflevector <8 x half> %764, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %926 = fpext <2 x half> %925 to <2 x float>
  %927 = shufflevector <8 x half> %764, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %928 = fpext <2 x half> %927 to <2 x float>
  %929 = shufflevector <8 x half> %764, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %930 = fpext <2 x half> %929 to <2 x float>
  %931 = shufflevector <8 x half> %764, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %932 = fpext <2 x half> %931 to <2 x float>
  %933 = shufflevector <8 x half> %768, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %934 = fpext <2 x half> %933 to <2 x float>
  %935 = shufflevector <8 x half> %768, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %936 = fpext <2 x half> %935 to <2 x float>
  %937 = shufflevector <8 x half> %768, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %938 = fpext <2 x half> %937 to <2 x float>
  %939 = shufflevector <8 x half> %768, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %940 = fpext <2 x half> %939 to <2 x float>
  %941 = shufflevector <8 x half> %772, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %942 = fpext <2 x half> %941 to <2 x float>
  %943 = shufflevector <8 x half> %772, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %944 = fpext <2 x half> %943 to <2 x float>
  %945 = shufflevector <8 x half> %772, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %946 = fpext <2 x half> %945 to <2 x float>
  %947 = shufflevector <8 x half> %772, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %948 = fpext <2 x half> %947 to <2 x float>
  %949 = shufflevector <8 x half> %776, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %950 = fpext <2 x half> %949 to <2 x float>
  %951 = shufflevector <8 x half> %776, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %952 = fpext <2 x half> %951 to <2 x float>
  %953 = shufflevector <8 x half> %776, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %954 = fpext <2 x half> %953 to <2 x float>
  %955 = shufflevector <8 x half> %776, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %956 = fpext <2 x half> %955 to <2 x float>
  %957 = shufflevector <8 x half> %780, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %958 = fpext <2 x half> %957 to <2 x float>
  %959 = shufflevector <8 x half> %780, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %960 = fpext <2 x half> %959 to <2 x float>
  %961 = shufflevector <8 x half> %780, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %962 = fpext <2 x half> %961 to <2 x float>
  %963 = shufflevector <8 x half> %780, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %964 = fpext <2 x half> %963 to <2 x float>
  %965 = shufflevector <8 x half> %784, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %966 = fpext <2 x half> %965 to <2 x float>
  %967 = shufflevector <8 x half> %784, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %968 = fpext <2 x half> %967 to <2 x float>
  %969 = shufflevector <8 x half> %784, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %970 = fpext <2 x half> %969 to <2 x float>
  %971 = shufflevector <8 x half> %784, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %972 = fpext <2 x half> %971 to <2 x float>
  %973 = shufflevector <8 x half> %788, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %974 = fpext <2 x half> %973 to <2 x float>
  %975 = shufflevector <8 x half> %788, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %976 = fpext <2 x half> %975 to <2 x float>
  %977 = shufflevector <8 x half> %788, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %978 = fpext <2 x half> %977 to <2 x float>
  %979 = shufflevector <8 x half> %788, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %980 = fpext <2 x half> %979 to <2 x float>
  %981 = shufflevector <8 x half> %792, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %982 = fpext <2 x half> %981 to <2 x float>
  %983 = shufflevector <8 x half> %792, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %984 = fpext <2 x half> %983 to <2 x float>
  %985 = shufflevector <8 x half> %792, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %986 = fpext <2 x half> %985 to <2 x float>
  %987 = shufflevector <8 x half> %792, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %988 = fpext <2 x half> %987 to <2 x float>
  %989 = shufflevector <8 x half> %796, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %990 = fpext <2 x half> %989 to <2 x float>
  %991 = shufflevector <8 x half> %796, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %992 = fpext <2 x half> %991 to <2 x float>
  %993 = shufflevector <8 x half> %796, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %994 = fpext <2 x half> %993 to <2 x float>
  %995 = shufflevector <8 x half> %796, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %996 = fpext <2 x half> %995 to <2 x float>
  %997 = shufflevector <8 x half> %800, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %998 = fpext <2 x half> %997 to <2 x float>
  %999 = shufflevector <8 x half> %800, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %1000 = fpext <2 x half> %999 to <2 x float>
  %1001 = shufflevector <8 x half> %800, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %1002 = fpext <2 x half> %1001 to <2 x float>
  %1003 = shufflevector <8 x half> %800, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %1004 = fpext <2 x half> %1003 to <2 x float>
  %1005 = shufflevector <8 x half> %804, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %1006 = fpext <2 x half> %1005 to <2 x float>
  %1007 = shufflevector <8 x half> %804, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %1008 = fpext <2 x half> %1007 to <2 x float>
  %1009 = shufflevector <8 x half> %804, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %1010 = fpext <2 x half> %1009 to <2 x float>
  %1011 = shufflevector <8 x half> %804, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %1012 = fpext <2 x half> %1011 to <2 x float>
  %1013 = shufflevector <8 x half> %808, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %1014 = fpext <2 x half> %1013 to <2 x float>
  %1015 = shufflevector <8 x half> %808, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %1016 = fpext <2 x half> %1015 to <2 x float>
  %1017 = shufflevector <8 x half> %808, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %1018 = fpext <2 x half> %1017 to <2 x float>
  %1019 = shufflevector <8 x half> %808, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %1020 = fpext <2 x half> %1019 to <2 x float>
  %1021 = shufflevector <8 x half> %812, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %1022 = fpext <2 x half> %1021 to <2 x float>
  %1023 = shufflevector <8 x half> %812, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %1024 = fpext <2 x half> %1023 to <2 x float>
  %1025 = shufflevector <8 x half> %812, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %1026 = fpext <2 x half> %1025 to <2 x float>
  %1027 = shufflevector <8 x half> %812, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %1028 = fpext <2 x half> %1027 to <2 x float>
  %1029 = shufflevector <8 x half> %816, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %1030 = fpext <2 x half> %1029 to <2 x float>
  %1031 = shufflevector <8 x half> %816, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %1032 = fpext <2 x half> %1031 to <2 x float>
  %1033 = shufflevector <8 x half> %816, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %1034 = fpext <2 x half> %1033 to <2 x float>
  %1035 = shufflevector <8 x half> %816, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %1036 = fpext <2 x half> %1035 to <2 x float>
  %1037 = shufflevector <8 x half> %820, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %1038 = fpext <2 x half> %1037 to <2 x float>
  %1039 = shufflevector <8 x half> %820, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %1040 = fpext <2 x half> %1039 to <2 x float>
  %1041 = shufflevector <8 x half> %820, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %1042 = fpext <2 x half> %1041 to <2 x float>
  %1043 = shufflevector <8 x half> %820, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %1044 = fpext <2 x half> %1043 to <2 x float>
  %1045 = shufflevector <8 x half> %824, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %1046 = fpext <2 x half> %1045 to <2 x float>
  %1047 = shufflevector <8 x half> %824, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %1048 = fpext <2 x half> %1047 to <2 x float>
  %1049 = shufflevector <8 x half> %824, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %1050 = fpext <2 x half> %1049 to <2 x float>
  %1051 = shufflevector <8 x half> %824, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %1052 = fpext <2 x half> %1051 to <2 x float>
  %1053 = shufflevector <8 x half> %828, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %1054 = fpext <2 x half> %1053 to <2 x float>
  %1055 = shufflevector <8 x half> %828, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %1056 = fpext <2 x half> %1055 to <2 x float>
  %1057 = shufflevector <8 x half> %828, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %1058 = fpext <2 x half> %1057 to <2 x float>
  %1059 = shufflevector <8 x half> %828, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %1060 = fpext <2 x half> %1059 to <2 x float>
  %1061 = shufflevector <8 x half> %832, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %1062 = fpext <2 x half> %1061 to <2 x float>
  %1063 = shufflevector <8 x half> %832, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %1064 = fpext <2 x half> %1063 to <2 x float>
  %1065 = shufflevector <8 x half> %832, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %1066 = fpext <2 x half> %1065 to <2 x float>
  %1067 = shufflevector <8 x half> %832, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %1068 = fpext <2 x half> %1067 to <2 x float>
  %1069 = shufflevector <8 x half> %836, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %1070 = fpext <2 x half> %1069 to <2 x float>
  %1071 = shufflevector <8 x half> %836, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %1072 = fpext <2 x half> %1071 to <2 x float>
  %1073 = shufflevector <8 x half> %836, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %1074 = fpext <2 x half> %1073 to <2 x float>
  %1075 = shufflevector <8 x half> %836, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %1076 = fpext <2 x half> %1075 to <2 x float>
  %1077 = shufflevector <8 x half> %840, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %1078 = fpext <2 x half> %1077 to <2 x float>
  %1079 = shufflevector <8 x half> %840, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %1080 = fpext <2 x half> %1079 to <2 x float>
  %1081 = shufflevector <8 x half> %840, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %1082 = fpext <2 x half> %1081 to <2 x float>
  %1083 = shufflevector <8 x half> %840, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %1084 = fpext <2 x half> %1083 to <2 x float>
  %1085 = shufflevector <8 x half> %844, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %1086 = fpext <2 x half> %1085 to <2 x float>
  %1087 = shufflevector <8 x half> %844, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %1088 = fpext <2 x half> %1087 to <2 x float>
  %1089 = shufflevector <8 x half> %844, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %1090 = fpext <2 x half> %1089 to <2 x float>
  %1091 = shufflevector <8 x half> %844, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %1092 = fpext <2 x half> %1091 to <2 x float>
  %1093 = shufflevector <8 x half> %848, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %1094 = fpext <2 x half> %1093 to <2 x float>
  %1095 = shufflevector <8 x half> %848, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %1096 = fpext <2 x half> %1095 to <2 x float>
  %1097 = shufflevector <8 x half> %848, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %1098 = fpext <2 x half> %1097 to <2 x float>
  %1099 = shufflevector <8 x half> %848, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %1100 = fpext <2 x half> %1099 to <2 x float>
  %1101 = fmul <2 x float> %470, %854
  %1102 = fmul <2 x float> %472, %856
  %1103 = fmul <2 x float> %474, %858
  %1104 = fmul <2 x float> %476, %860
  %1105 = fmul <2 x float> %478, %862
  %1106 = fmul <2 x float> %480, %864
  %1107 = fmul <2 x float> %482, %866
  %1108 = fmul <2 x float> %484, %868
  %1109 = fmul <2 x float> %486, %870
  %1110 = fmul <2 x float> %488, %872
  %1111 = fmul <2 x float> %490, %874
  %1112 = fmul <2 x float> %492, %876
  %1113 = fmul <2 x float> %494, %878
  %1114 = fmul <2 x float> %496, %880
  %1115 = fmul <2 x float> %498, %882
  %1116 = fmul <2 x float> %500, %884
  %1117 = fmul <2 x float> %502, %886
  %1118 = fmul <2 x float> %504, %888
  %1119 = fmul <2 x float> %506, %890
  %1120 = fmul <2 x float> %508, %892
  %1121 = fmul <2 x float> %510, %894
  %1122 = fmul <2 x float> %512, %896
  %1123 = fmul <2 x float> %514, %898
  %1124 = fmul <2 x float> %516, %900
  %1125 = fmul <2 x float> %518, %902
  %1126 = fmul <2 x float> %520, %904
  %1127 = fmul <2 x float> %522, %906
  %1128 = fmul <2 x float> %524, %908
  %1129 = fmul <2 x float> %526, %910
  %1130 = fmul <2 x float> %528, %912
  %1131 = fmul <2 x float> %530, %914
  %1132 = fmul <2 x float> %532, %916
  %1133 = fmul <2 x float> %534, %918
  %1134 = fmul <2 x float> %536, %920
  %1135 = fmul <2 x float> %538, %922
  %1136 = fmul <2 x float> %540, %924
  %1137 = fmul <2 x float> %542, %926
  %1138 = fmul <2 x float> %544, %928
  %1139 = fmul <2 x float> %546, %930
  %1140 = fmul <2 x float> %548, %932
  %1141 = fmul <2 x float> %550, %934
  %1142 = fmul <2 x float> %552, %936
  %1143 = fmul <2 x float> %554, %938
  %1144 = fmul <2 x float> %556, %940
  %1145 = fmul <2 x float> %558, %942
  %1146 = fmul <2 x float> %560, %944
  %1147 = fmul <2 x float> %562, %946
  %1148 = fmul <2 x float> %564, %948
  %1149 = fmul <2 x float> %566, %950
  %1150 = fmul <2 x float> %568, %952
  %1151 = fmul <2 x float> %570, %954
  %1152 = fmul <2 x float> %572, %956
  %1153 = fmul <2 x float> %574, %958
  %1154 = fmul <2 x float> %576, %960
  %1155 = fmul <2 x float> %578, %962
  %1156 = fmul <2 x float> %580, %964
  %1157 = fmul <2 x float> %582, %966
  %1158 = fmul <2 x float> %584, %968
  %1159 = fmul <2 x float> %586, %970
  %1160 = fmul <2 x float> %588, %972
  %1161 = fmul <2 x float> %590, %974
  %1162 = fmul <2 x float> %592, %976
  %1163 = fmul <2 x float> %594, %978
  %1164 = fmul <2 x float> %596, %980
  %1165 = fmul <2 x float> %598, %982
  %1166 = fmul <2 x float> %600, %984
  %1167 = fmul <2 x float> %602, %986
  %1168 = fmul <2 x float> %604, %988
  %1169 = fmul <2 x float> %606, %990
  %1170 = fmul <2 x float> %608, %992
  %1171 = fmul <2 x float> %610, %994
  %1172 = fmul <2 x float> %612, %996
  %1173 = fmul <2 x float> %614, %998
  %1174 = fmul <2 x float> %616, %1000
  %1175 = fmul <2 x float> %618, %1002
  %1176 = fmul <2 x float> %620, %1004
  %1177 = fmul <2 x float> %622, %1006
  %1178 = fmul <2 x float> %624, %1008
  %1179 = fmul <2 x float> %626, %1010
  %1180 = fmul <2 x float> %628, %1012
  %1181 = fmul <2 x float> %630, %1014
  %1182 = fmul <2 x float> %632, %1016
  %1183 = fmul <2 x float> %634, %1018
  %1184 = fmul <2 x float> %636, %1020
  %1185 = fmul <2 x float> %638, %1022
  %1186 = fmul <2 x float> %640, %1024
  %1187 = fmul <2 x float> %642, %1026
  %1188 = fmul <2 x float> %644, %1028
  %1189 = fmul <2 x float> %646, %1030
  %1190 = fmul <2 x float> %648, %1032
  %1191 = fmul <2 x float> %650, %1034
  %1192 = fmul <2 x float> %652, %1036
  %1193 = fmul <2 x float> %654, %1038
  %1194 = fmul <2 x float> %656, %1040
  %1195 = fmul <2 x float> %658, %1042
  %1196 = fmul <2 x float> %660, %1044
  %1197 = fmul <2 x float> %662, %1046
  %1198 = fmul <2 x float> %664, %1048
  %1199 = fmul <2 x float> %666, %1050
  %1200 = fmul <2 x float> %668, %1052
  %1201 = fmul <2 x float> %670, %1054
  %1202 = fmul <2 x float> %672, %1056
  %1203 = fmul <2 x float> %674, %1058
  %1204 = fmul <2 x float> %676, %1060
  %1205 = fmul <2 x float> %678, %1062
  %1206 = fmul <2 x float> %680, %1064
  %1207 = fmul <2 x float> %682, %1066
  %1208 = fmul <2 x float> %684, %1068
  %1209 = fmul <2 x float> %686, %1070
  %1210 = fmul <2 x float> %688, %1072
  %1211 = fmul <2 x float> %690, %1074
  %1212 = fmul <2 x float> %692, %1076
  %1213 = fmul <2 x float> %694, %1078
  %1214 = fmul <2 x float> %696, %1080
  %1215 = fmul <2 x float> %698, %1082
  %1216 = fmul <2 x float> %700, %1084
  %1217 = fmul <2 x float> %702, %1086
  %1218 = fmul <2 x float> %704, %1088
  %1219 = fmul <2 x float> %706, %1090
  %1220 = fmul <2 x float> %708, %1092
  %1221 = fmul <2 x float> %710, %1094
  %1222 = fmul <2 x float> %712, %1096
  %1223 = fmul <2 x float> %714, %1098
  %1224 = fmul <2 x float> %716, %1100
  %1225 = shufflevector <8 x half> %852, <8 x half> poison, <2 x i32> <i32 0, i32 1>
  %1226 = fpext <2 x half> %1225 to <2 x float>
  %1227 = fmul <2 x float> %718, %1226
  %1228 = shufflevector <8 x half> %852, <8 x half> poison, <2 x i32> <i32 2, i32 3>
  %1229 = fpext <2 x half> %1228 to <2 x float>
  %1230 = fmul <2 x float> %720, %1229
  %1231 = shufflevector <8 x half> %852, <8 x half> poison, <2 x i32> <i32 4, i32 5>
  %1232 = fpext <2 x half> %1231 to <2 x float>
  %1233 = fmul <2 x float> %722, %1232
  %1234 = shufflevector <8 x half> %852, <8 x half> poison, <2 x i32> <i32 6, i32 7>
  %1235 = fpext <2 x half> %1234 to <2 x float>
  %1236 = fmul <2 x float> %724, %1235
  %1237 = fadd <2 x float> %1101, %1102
  %1238 = fadd <2 x float> %1103, %1104
  %1239 = fadd <2 x float> %1237, %1238
  %1240 = fadd <2 x float> %1105, %1106
  %1241 = fadd <2 x float> %1107, %1108
  %1242 = fadd <2 x float> %1240, %1241
  %1243 = fadd <2 x float> %1109, %1110
  %1244 = fadd <2 x float> %1111, %1112
  %1245 = fadd <2 x float> %1243, %1244
  %1246 = fadd <2 x float> %1113, %1114
  %1247 = fadd <2 x float> %1115, %1116
  %1248 = fadd <2 x float> %1246, %1247
  %1249 = fadd <2 x float> %1117, %1118
  %1250 = fadd <2 x float> %1119, %1120
  %1251 = fadd <2 x float> %1249, %1250
  %1252 = fadd <2 x float> %1121, %1122
  %1253 = fadd <2 x float> %1123, %1124
  %1254 = fadd <2 x float> %1252, %1253
  %1255 = fadd <2 x float> %1125, %1126
  %1256 = fadd <2 x float> %1127, %1128
  %1257 = fadd <2 x float> %1255, %1256
  %1258 = fadd <2 x float> %1129, %1130
  %1259 = fadd <2 x float> %1131, %1132
  %1260 = fadd <2 x float> %1258, %1259
  %1261 = fadd <2 x float> %1133, %1134
  %1262 = fadd <2 x float> %1135, %1136
  %1263 = fadd <2 x float> %1261, %1262
  %1264 = fadd <2 x float> %1137, %1138
  %1265 = fadd <2 x float> %1139, %1140
  %1266 = fadd <2 x float> %1264, %1265
  %1267 = fadd <2 x float> %1141, %1142
  %1268 = fadd <2 x float> %1143, %1144
  %1269 = fadd <2 x float> %1267, %1268
  %1270 = fadd <2 x float> %1145, %1146
  %1271 = fadd <2 x float> %1147, %1148
  %1272 = fadd <2 x float> %1270, %1271
  %1273 = fadd <2 x float> %1149, %1150
  %1274 = fadd <2 x float> %1151, %1152
  %1275 = fadd <2 x float> %1273, %1274
  %1276 = fadd <2 x float> %1153, %1154
  %1277 = fadd <2 x float> %1155, %1156
  %1278 = fadd <2 x float> %1276, %1277
  %1279 = fadd <2 x float> %1157, %1158
  %1280 = fadd <2 x float> %1159, %1160
  %1281 = fadd <2 x float> %1279, %1280
  %1282 = fadd <2 x float> %1161, %1162
  %1283 = fadd <2 x float> %1163, %1164
  %1284 = fadd <2 x float> %1282, %1283
  %1285 = fadd <2 x float> %1165, %1166
  %1286 = fadd <2 x float> %1167, %1168
  %1287 = fadd <2 x float> %1285, %1286
  %1288 = fadd <2 x float> %1169, %1170
  %1289 = fadd <2 x float> %1171, %1172
  %1290 = fadd <2 x float> %1288, %1289
  %1291 = fadd <2 x float> %1173, %1174
  %1292 = fadd <2 x float> %1175, %1176
  %1293 = fadd <2 x float> %1291, %1292
  %1294 = fadd <2 x float> %1177, %1178
  %1295 = fadd <2 x float> %1179, %1180
  %1296 = fadd <2 x float> %1294, %1295
  %1297 = fadd <2 x float> %1181, %1182
  %1298 = fadd <2 x float> %1183, %1184
  %1299 = fadd <2 x float> %1297, %1298
  %1300 = fadd <2 x float> %1185, %1186
  %1301 = fadd <2 x float> %1187, %1188
  %1302 = fadd <2 x float> %1300, %1301
  %1303 = fadd <2 x float> %1189, %1190
  %1304 = fadd <2 x float> %1191, %1192
  %1305 = fadd <2 x float> %1303, %1304
  %1306 = fadd <2 x float> %1193, %1194
  %1307 = fadd <2 x float> %1195, %1196
  %1308 = fadd <2 x float> %1306, %1307
  %1309 = fadd <2 x float> %1197, %1198
  %1310 = fadd <2 x float> %1199, %1200
  %1311 = fadd <2 x float> %1309, %1310
  %1312 = fadd <2 x float> %1201, %1202
  %1313 = fadd <2 x float> %1203, %1204
  %1314 = fadd <2 x float> %1312, %1313
  %1315 = fadd <2 x float> %1205, %1206
  %1316 = fadd <2 x float> %1207, %1208
  %1317 = fadd <2 x float> %1315, %1316
  %1318 = fadd <2 x float> %1209, %1210
  %1319 = fadd <2 x float> %1211, %1212
  %1320 = fadd <2 x float> %1318, %1319
  %1321 = fadd <2 x float> %1213, %1214
  %1322 = fadd <2 x float> %1215, %1216
  %1323 = fadd <2 x float> %1321, %1322
  %1324 = fadd <2 x float> %1217, %1218
  %1325 = fadd <2 x float> %1219, %1220
  %1326 = fadd <2 x float> %1324, %1325
  %1327 = fadd <2 x float> %1221, %1222
  %1328 = fadd <2 x float> %1223, %1224
  %1329 = fadd <2 x float> %1327, %1328
  %1330 = fadd <2 x float> %1227, %1230
  %1331 = fadd <2 x float> %1233, %1236
  %1332 = fadd <2 x float> %1330, %1331
  %1333 = shufflevector <2 x float> %1239, <2 x float> %1242, <2 x i32> <i32 0, i32 2>
  %1334 = shufflevector <2 x float> %1239, <2 x float> %1242, <2 x i32> <i32 1, i32 3>
  %1335 = fadd <2 x float> %1333, %1334
  %1336 = extractelement <2 x float> %1335, i64 0
  %1337 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1336, i32 280, i32 15, i32 15, i1 true)
  %1338 = extractelement <2 x float> %1335, i64 1
  %1339 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1338, i32 280, i32 15, i32 15, i1 true)
  %1340 = insertelement <2 x float> poison, float %1337, i64 0
  %1341 = insertelement <2 x float> %1340, float %1339, i64 1
  %1342 = fadd <2 x float> %1335, %1341
  %1343 = extractelement <2 x float> %1342, i64 0
  %1344 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1343, i32 276, i32 15, i32 15, i1 true)
  %1345 = extractelement <2 x float> %1342, i64 1
  %1346 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1345, i32 276, i32 15, i32 15, i1 true)
  %1347 = insertelement <2 x float> poison, float %1344, i64 0
  %1348 = insertelement <2 x float> %1347, float %1346, i64 1
  %1349 = fadd <2 x float> %1342, %1348
  %1350 = extractelement <2 x float> %1349, i64 0
  %1351 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1350, i32 274, i32 15, i32 15, i1 true)
  %1352 = extractelement <2 x float> %1349, i64 1
  %1353 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1352, i32 274, i32 15, i32 15, i1 true)
  %1354 = insertelement <2 x float> poison, float %1351, i64 0
  %1355 = insertelement <2 x float> %1354, float %1353, i64 1
  %1356 = fadd <2 x float> %1349, %1355
  %1357 = extractelement <2 x float> %1356, i64 0
  %1358 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1357, i32 273, i32 15, i32 15, i1 true)
  %1359 = extractelement <2 x float> %1356, i64 1
  %1360 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1359, i32 273, i32 15, i32 15, i1 true)
  %1361 = insertelement <2 x float> poison, float %1358, i64 0
  %1362 = insertelement <2 x float> %1361, float %1360, i64 1
  %1363 = fadd <2 x float> %1356, %1362
  %1364 = extractelement <2 x float> %1363, i64 0
  %1365 = tail call float @llvm.amdgcn.update.dpp.f32(float %1364, float %1364, i32 322, i32 10, i32 15, i1 true)
  %1366 = extractelement <2 x float> %1363, i64 1
  %1367 = tail call float @llvm.amdgcn.update.dpp.f32(float %1366, float %1366, i32 322, i32 10, i32 15, i1 true)
  %1368 = insertelement <2 x float> poison, float %1365, i64 0
  %1369 = insertelement <2 x float> %1368, float %1367, i64 1
  %1370 = fadd <2 x float> %1363, %1369
  %1371 = extractelement <2 x float> %1370, i64 0
  %1372 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1371, i32 323, i32 15, i32 15, i1 true)
  %1373 = extractelement <2 x float> %1370, i64 1
  %1374 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1373, i32 323, i32 15, i32 15, i1 true)
  %1375 = insertelement <2 x float> poison, float %1372, i64 0
  %1376 = insertelement <2 x float> %1375, float %1374, i64 1
  %1377 = fadd <2 x float> %1370, %1376
  %1378 = extractelement <2 x float> %1377, i64 0
  %1379 = tail call float @llvm.amdgcn.readlane.f32(float %1378, i32 63)
  %1380 = extractelement <2 x float> %1377, i64 1
  %1381 = tail call float @llvm.amdgcn.readlane.f32(float %1380, i32 63)
  %1382 = shufflevector <2 x float> %1245, <2 x float> %1248, <2 x i32> <i32 0, i32 2>
  %1383 = shufflevector <2 x float> %1245, <2 x float> %1248, <2 x i32> <i32 1, i32 3>
  %1384 = fadd <2 x float> %1382, %1383
  %1385 = extractelement <2 x float> %1384, i64 0
  %1386 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1385, i32 280, i32 15, i32 15, i1 true)
  %1387 = extractelement <2 x float> %1384, i64 1
  %1388 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1387, i32 280, i32 15, i32 15, i1 true)
  %1389 = insertelement <2 x float> poison, float %1386, i64 0
  %1390 = insertelement <2 x float> %1389, float %1388, i64 1
  %1391 = fadd <2 x float> %1384, %1390
  %1392 = extractelement <2 x float> %1391, i64 0
  %1393 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1392, i32 276, i32 15, i32 15, i1 true)
  %1394 = extractelement <2 x float> %1391, i64 1
  %1395 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1394, i32 276, i32 15, i32 15, i1 true)
  %1396 = insertelement <2 x float> poison, float %1393, i64 0
  %1397 = insertelement <2 x float> %1396, float %1395, i64 1
  %1398 = fadd <2 x float> %1391, %1397
  %1399 = extractelement <2 x float> %1398, i64 0
  %1400 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1399, i32 274, i32 15, i32 15, i1 true)
  %1401 = extractelement <2 x float> %1398, i64 1
  %1402 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1401, i32 274, i32 15, i32 15, i1 true)
  %1403 = insertelement <2 x float> poison, float %1400, i64 0
  %1404 = insertelement <2 x float> %1403, float %1402, i64 1
  %1405 = fadd <2 x float> %1398, %1404
  %1406 = extractelement <2 x float> %1405, i64 0
  %1407 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1406, i32 273, i32 15, i32 15, i1 true)
  %1408 = extractelement <2 x float> %1405, i64 1
  %1409 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1408, i32 273, i32 15, i32 15, i1 true)
  %1410 = insertelement <2 x float> poison, float %1407, i64 0
  %1411 = insertelement <2 x float> %1410, float %1409, i64 1
  %1412 = fadd <2 x float> %1405, %1411
  %1413 = extractelement <2 x float> %1412, i64 0
  %1414 = tail call float @llvm.amdgcn.update.dpp.f32(float %1413, float %1413, i32 322, i32 10, i32 15, i1 true)
  %1415 = extractelement <2 x float> %1412, i64 1
  %1416 = tail call float @llvm.amdgcn.update.dpp.f32(float %1415, float %1415, i32 322, i32 10, i32 15, i1 true)
  %1417 = insertelement <2 x float> poison, float %1414, i64 0
  %1418 = insertelement <2 x float> %1417, float %1416, i64 1
  %1419 = fadd <2 x float> %1412, %1418
  %1420 = extractelement <2 x float> %1419, i64 0
  %1421 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1420, i32 323, i32 15, i32 15, i1 true)
  %1422 = extractelement <2 x float> %1419, i64 1
  %1423 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1422, i32 323, i32 15, i32 15, i1 true)
  %1424 = insertelement <2 x float> poison, float %1421, i64 0
  %1425 = insertelement <2 x float> %1424, float %1423, i64 1
  %1426 = fadd <2 x float> %1419, %1425
  %1427 = extractelement <2 x float> %1426, i64 0
  %1428 = tail call float @llvm.amdgcn.readlane.f32(float %1427, i32 63)
  %1429 = extractelement <2 x float> %1426, i64 1
  %1430 = tail call float @llvm.amdgcn.readlane.f32(float %1429, i32 63)
  %1431 = shufflevector <2 x float> %1251, <2 x float> %1254, <2 x i32> <i32 0, i32 2>
  %1432 = shufflevector <2 x float> %1251, <2 x float> %1254, <2 x i32> <i32 1, i32 3>
  %1433 = fadd <2 x float> %1431, %1432
  %1434 = extractelement <2 x float> %1433, i64 0
  %1435 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1434, i32 280, i32 15, i32 15, i1 true)
  %1436 = extractelement <2 x float> %1433, i64 1
  %1437 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1436, i32 280, i32 15, i32 15, i1 true)
  %1438 = insertelement <2 x float> poison, float %1435, i64 0
  %1439 = insertelement <2 x float> %1438, float %1437, i64 1
  %1440 = fadd <2 x float> %1433, %1439
  %1441 = extractelement <2 x float> %1440, i64 0
  %1442 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1441, i32 276, i32 15, i32 15, i1 true)
  %1443 = extractelement <2 x float> %1440, i64 1
  %1444 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1443, i32 276, i32 15, i32 15, i1 true)
  %1445 = insertelement <2 x float> poison, float %1442, i64 0
  %1446 = insertelement <2 x float> %1445, float %1444, i64 1
  %1447 = fadd <2 x float> %1440, %1446
  %1448 = extractelement <2 x float> %1447, i64 0
  %1449 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1448, i32 274, i32 15, i32 15, i1 true)
  %1450 = extractelement <2 x float> %1447, i64 1
  %1451 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1450, i32 274, i32 15, i32 15, i1 true)
  %1452 = insertelement <2 x float> poison, float %1449, i64 0
  %1453 = insertelement <2 x float> %1452, float %1451, i64 1
  %1454 = fadd <2 x float> %1447, %1453
  %1455 = extractelement <2 x float> %1454, i64 0
  %1456 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1455, i32 273, i32 15, i32 15, i1 true)
  %1457 = extractelement <2 x float> %1454, i64 1
  %1458 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1457, i32 273, i32 15, i32 15, i1 true)
  %1459 = insertelement <2 x float> poison, float %1456, i64 0
  %1460 = insertelement <2 x float> %1459, float %1458, i64 1
  %1461 = fadd <2 x float> %1454, %1460
  %1462 = extractelement <2 x float> %1461, i64 0
  %1463 = tail call float @llvm.amdgcn.update.dpp.f32(float %1462, float %1462, i32 322, i32 10, i32 15, i1 true)
  %1464 = extractelement <2 x float> %1461, i64 1
  %1465 = tail call float @llvm.amdgcn.update.dpp.f32(float %1464, float %1464, i32 322, i32 10, i32 15, i1 true)
  %1466 = insertelement <2 x float> poison, float %1463, i64 0
  %1467 = insertelement <2 x float> %1466, float %1465, i64 1
  %1468 = fadd <2 x float> %1461, %1467
  %1469 = extractelement <2 x float> %1468, i64 0
  %1470 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1469, i32 323, i32 15, i32 15, i1 true)
  %1471 = extractelement <2 x float> %1468, i64 1
  %1472 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1471, i32 323, i32 15, i32 15, i1 true)
  %1473 = insertelement <2 x float> poison, float %1470, i64 0
  %1474 = insertelement <2 x float> %1473, float %1472, i64 1
  %1475 = fadd <2 x float> %1468, %1474
  %1476 = extractelement <2 x float> %1475, i64 0
  %1477 = tail call float @llvm.amdgcn.readlane.f32(float %1476, i32 63)
  %1478 = extractelement <2 x float> %1475, i64 1
  %1479 = tail call float @llvm.amdgcn.readlane.f32(float %1478, i32 63)
  %1480 = shufflevector <2 x float> %1257, <2 x float> %1260, <2 x i32> <i32 0, i32 2>
  %1481 = shufflevector <2 x float> %1257, <2 x float> %1260, <2 x i32> <i32 1, i32 3>
  %1482 = fadd <2 x float> %1480, %1481
  %1483 = extractelement <2 x float> %1482, i64 0
  %1484 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1483, i32 280, i32 15, i32 15, i1 true)
  %1485 = extractelement <2 x float> %1482, i64 1
  %1486 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1485, i32 280, i32 15, i32 15, i1 true)
  %1487 = insertelement <2 x float> poison, float %1484, i64 0
  %1488 = insertelement <2 x float> %1487, float %1486, i64 1
  %1489 = fadd <2 x float> %1482, %1488
  %1490 = extractelement <2 x float> %1489, i64 0
  %1491 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1490, i32 276, i32 15, i32 15, i1 true)
  %1492 = extractelement <2 x float> %1489, i64 1
  %1493 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1492, i32 276, i32 15, i32 15, i1 true)
  %1494 = insertelement <2 x float> poison, float %1491, i64 0
  %1495 = insertelement <2 x float> %1494, float %1493, i64 1
  %1496 = fadd <2 x float> %1489, %1495
  %1497 = extractelement <2 x float> %1496, i64 0
  %1498 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1497, i32 274, i32 15, i32 15, i1 true)
  %1499 = extractelement <2 x float> %1496, i64 1
  %1500 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1499, i32 274, i32 15, i32 15, i1 true)
  %1501 = insertelement <2 x float> poison, float %1498, i64 0
  %1502 = insertelement <2 x float> %1501, float %1500, i64 1
  %1503 = fadd <2 x float> %1496, %1502
  %1504 = extractelement <2 x float> %1503, i64 0
  %1505 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1504, i32 273, i32 15, i32 15, i1 true)
  %1506 = extractelement <2 x float> %1503, i64 1
  %1507 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1506, i32 273, i32 15, i32 15, i1 true)
  %1508 = insertelement <2 x float> poison, float %1505, i64 0
  %1509 = insertelement <2 x float> %1508, float %1507, i64 1
  %1510 = fadd <2 x float> %1503, %1509
  %1511 = extractelement <2 x float> %1510, i64 0
  %1512 = tail call float @llvm.amdgcn.update.dpp.f32(float %1511, float %1511, i32 322, i32 10, i32 15, i1 true)
  %1513 = extractelement <2 x float> %1510, i64 1
  %1514 = tail call float @llvm.amdgcn.update.dpp.f32(float %1513, float %1513, i32 322, i32 10, i32 15, i1 true)
  %1515 = insertelement <2 x float> poison, float %1512, i64 0
  %1516 = insertelement <2 x float> %1515, float %1514, i64 1
  %1517 = fadd <2 x float> %1510, %1516
  %1518 = extractelement <2 x float> %1517, i64 0
  %1519 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1518, i32 323, i32 15, i32 15, i1 true)
  %1520 = extractelement <2 x float> %1517, i64 1
  %1521 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1520, i32 323, i32 15, i32 15, i1 true)
  %1522 = insertelement <2 x float> poison, float %1519, i64 0
  %1523 = insertelement <2 x float> %1522, float %1521, i64 1
  %1524 = fadd <2 x float> %1517, %1523
  %1525 = extractelement <2 x float> %1524, i64 0
  %1526 = tail call float @llvm.amdgcn.readlane.f32(float %1525, i32 63)
  %1527 = extractelement <2 x float> %1524, i64 1
  %1528 = tail call float @llvm.amdgcn.readlane.f32(float %1527, i32 63)
  %1529 = shufflevector <2 x float> %1263, <2 x float> %1266, <2 x i32> <i32 0, i32 2>
  %1530 = shufflevector <2 x float> %1263, <2 x float> %1266, <2 x i32> <i32 1, i32 3>
  %1531 = fadd <2 x float> %1529, %1530
  %1532 = extractelement <2 x float> %1531, i64 0
  %1533 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1532, i32 280, i32 15, i32 15, i1 true)
  %1534 = extractelement <2 x float> %1531, i64 1
  %1535 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1534, i32 280, i32 15, i32 15, i1 true)
  %1536 = insertelement <2 x float> poison, float %1533, i64 0
  %1537 = insertelement <2 x float> %1536, float %1535, i64 1
  %1538 = fadd <2 x float> %1531, %1537
  %1539 = extractelement <2 x float> %1538, i64 0
  %1540 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1539, i32 276, i32 15, i32 15, i1 true)
  %1541 = extractelement <2 x float> %1538, i64 1
  %1542 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1541, i32 276, i32 15, i32 15, i1 true)
  %1543 = insertelement <2 x float> poison, float %1540, i64 0
  %1544 = insertelement <2 x float> %1543, float %1542, i64 1
  %1545 = fadd <2 x float> %1538, %1544
  %1546 = extractelement <2 x float> %1545, i64 0
  %1547 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1546, i32 274, i32 15, i32 15, i1 true)
  %1548 = extractelement <2 x float> %1545, i64 1
  %1549 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1548, i32 274, i32 15, i32 15, i1 true)
  %1550 = insertelement <2 x float> poison, float %1547, i64 0
  %1551 = insertelement <2 x float> %1550, float %1549, i64 1
  %1552 = fadd <2 x float> %1545, %1551
  %1553 = extractelement <2 x float> %1552, i64 0
  %1554 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1553, i32 273, i32 15, i32 15, i1 true)
  %1555 = extractelement <2 x float> %1552, i64 1
  %1556 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1555, i32 273, i32 15, i32 15, i1 true)
  %1557 = insertelement <2 x float> poison, float %1554, i64 0
  %1558 = insertelement <2 x float> %1557, float %1556, i64 1
  %1559 = fadd <2 x float> %1552, %1558
  %1560 = extractelement <2 x float> %1559, i64 0
  %1561 = tail call float @llvm.amdgcn.update.dpp.f32(float %1560, float %1560, i32 322, i32 10, i32 15, i1 true)
  %1562 = extractelement <2 x float> %1559, i64 1
  %1563 = tail call float @llvm.amdgcn.update.dpp.f32(float %1562, float %1562, i32 322, i32 10, i32 15, i1 true)
  %1564 = insertelement <2 x float> poison, float %1561, i64 0
  %1565 = insertelement <2 x float> %1564, float %1563, i64 1
  %1566 = fadd <2 x float> %1559, %1565
  %1567 = extractelement <2 x float> %1566, i64 0
  %1568 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1567, i32 323, i32 15, i32 15, i1 true)
  %1569 = extractelement <2 x float> %1566, i64 1
  %1570 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1569, i32 323, i32 15, i32 15, i1 true)
  %1571 = insertelement <2 x float> poison, float %1568, i64 0
  %1572 = insertelement <2 x float> %1571, float %1570, i64 1
  %1573 = fadd <2 x float> %1566, %1572
  %1574 = extractelement <2 x float> %1573, i64 0
  %1575 = tail call float @llvm.amdgcn.readlane.f32(float %1574, i32 63)
  %1576 = extractelement <2 x float> %1573, i64 1
  %1577 = tail call float @llvm.amdgcn.readlane.f32(float %1576, i32 63)
  %1578 = shufflevector <2 x float> %1269, <2 x float> %1272, <2 x i32> <i32 0, i32 2>
  %1579 = shufflevector <2 x float> %1269, <2 x float> %1272, <2 x i32> <i32 1, i32 3>
  %1580 = fadd <2 x float> %1578, %1579
  %1581 = extractelement <2 x float> %1580, i64 0
  %1582 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1581, i32 280, i32 15, i32 15, i1 true)
  %1583 = extractelement <2 x float> %1580, i64 1
  %1584 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1583, i32 280, i32 15, i32 15, i1 true)
  %1585 = insertelement <2 x float> poison, float %1582, i64 0
  %1586 = insertelement <2 x float> %1585, float %1584, i64 1
  %1587 = fadd <2 x float> %1580, %1586
  %1588 = extractelement <2 x float> %1587, i64 0
  %1589 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1588, i32 276, i32 15, i32 15, i1 true)
  %1590 = extractelement <2 x float> %1587, i64 1
  %1591 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1590, i32 276, i32 15, i32 15, i1 true)
  %1592 = insertelement <2 x float> poison, float %1589, i64 0
  %1593 = insertelement <2 x float> %1592, float %1591, i64 1
  %1594 = fadd <2 x float> %1587, %1593
  %1595 = extractelement <2 x float> %1594, i64 0
  %1596 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1595, i32 274, i32 15, i32 15, i1 true)
  %1597 = extractelement <2 x float> %1594, i64 1
  %1598 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1597, i32 274, i32 15, i32 15, i1 true)
  %1599 = insertelement <2 x float> poison, float %1596, i64 0
  %1600 = insertelement <2 x float> %1599, float %1598, i64 1
  %1601 = fadd <2 x float> %1594, %1600
  %1602 = extractelement <2 x float> %1601, i64 0
  %1603 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1602, i32 273, i32 15, i32 15, i1 true)
  %1604 = extractelement <2 x float> %1601, i64 1
  %1605 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1604, i32 273, i32 15, i32 15, i1 true)
  %1606 = insertelement <2 x float> poison, float %1603, i64 0
  %1607 = insertelement <2 x float> %1606, float %1605, i64 1
  %1608 = fadd <2 x float> %1601, %1607
  %1609 = extractelement <2 x float> %1608, i64 0
  %1610 = tail call float @llvm.amdgcn.update.dpp.f32(float %1609, float %1609, i32 322, i32 10, i32 15, i1 true)
  %1611 = extractelement <2 x float> %1608, i64 1
  %1612 = tail call float @llvm.amdgcn.update.dpp.f32(float %1611, float %1611, i32 322, i32 10, i32 15, i1 true)
  %1613 = insertelement <2 x float> poison, float %1610, i64 0
  %1614 = insertelement <2 x float> %1613, float %1612, i64 1
  %1615 = fadd <2 x float> %1608, %1614
  %1616 = extractelement <2 x float> %1615, i64 0
  %1617 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1616, i32 323, i32 15, i32 15, i1 true)
  %1618 = extractelement <2 x float> %1615, i64 1
  %1619 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1618, i32 323, i32 15, i32 15, i1 true)
  %1620 = insertelement <2 x float> poison, float %1617, i64 0
  %1621 = insertelement <2 x float> %1620, float %1619, i64 1
  %1622 = fadd <2 x float> %1615, %1621
  %1623 = extractelement <2 x float> %1622, i64 0
  %1624 = tail call float @llvm.amdgcn.readlane.f32(float %1623, i32 63)
  %1625 = extractelement <2 x float> %1622, i64 1
  %1626 = tail call float @llvm.amdgcn.readlane.f32(float %1625, i32 63)
  %1627 = shufflevector <2 x float> %1275, <2 x float> %1278, <2 x i32> <i32 0, i32 2>
  %1628 = shufflevector <2 x float> %1275, <2 x float> %1278, <2 x i32> <i32 1, i32 3>
  %1629 = fadd <2 x float> %1627, %1628
  %1630 = extractelement <2 x float> %1629, i64 0
  %1631 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1630, i32 280, i32 15, i32 15, i1 true)
  %1632 = extractelement <2 x float> %1629, i64 1
  %1633 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1632, i32 280, i32 15, i32 15, i1 true)
  %1634 = insertelement <2 x float> poison, float %1631, i64 0
  %1635 = insertelement <2 x float> %1634, float %1633, i64 1
  %1636 = fadd <2 x float> %1629, %1635
  %1637 = extractelement <2 x float> %1636, i64 0
  %1638 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1637, i32 276, i32 15, i32 15, i1 true)
  %1639 = extractelement <2 x float> %1636, i64 1
  %1640 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1639, i32 276, i32 15, i32 15, i1 true)
  %1641 = insertelement <2 x float> poison, float %1638, i64 0
  %1642 = insertelement <2 x float> %1641, float %1640, i64 1
  %1643 = fadd <2 x float> %1636, %1642
  %1644 = extractelement <2 x float> %1643, i64 0
  %1645 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1644, i32 274, i32 15, i32 15, i1 true)
  %1646 = extractelement <2 x float> %1643, i64 1
  %1647 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1646, i32 274, i32 15, i32 15, i1 true)
  %1648 = insertelement <2 x float> poison, float %1645, i64 0
  %1649 = insertelement <2 x float> %1648, float %1647, i64 1
  %1650 = fadd <2 x float> %1643, %1649
  %1651 = extractelement <2 x float> %1650, i64 0
  %1652 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1651, i32 273, i32 15, i32 15, i1 true)
  %1653 = extractelement <2 x float> %1650, i64 1
  %1654 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1653, i32 273, i32 15, i32 15, i1 true)
  %1655 = insertelement <2 x float> poison, float %1652, i64 0
  %1656 = insertelement <2 x float> %1655, float %1654, i64 1
  %1657 = fadd <2 x float> %1650, %1656
  %1658 = extractelement <2 x float> %1657, i64 0
  %1659 = tail call float @llvm.amdgcn.update.dpp.f32(float %1658, float %1658, i32 322, i32 10, i32 15, i1 true)
  %1660 = extractelement <2 x float> %1657, i64 1
  %1661 = tail call float @llvm.amdgcn.update.dpp.f32(float %1660, float %1660, i32 322, i32 10, i32 15, i1 true)
  %1662 = insertelement <2 x float> poison, float %1659, i64 0
  %1663 = insertelement <2 x float> %1662, float %1661, i64 1
  %1664 = fadd <2 x float> %1657, %1663
  %1665 = extractelement <2 x float> %1664, i64 0
  %1666 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1665, i32 323, i32 15, i32 15, i1 true)
  %1667 = extractelement <2 x float> %1664, i64 1
  %1668 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1667, i32 323, i32 15, i32 15, i1 true)
  %1669 = insertelement <2 x float> poison, float %1666, i64 0
  %1670 = insertelement <2 x float> %1669, float %1668, i64 1
  %1671 = fadd <2 x float> %1664, %1670
  %1672 = extractelement <2 x float> %1671, i64 0
  %1673 = tail call float @llvm.amdgcn.readlane.f32(float %1672, i32 63)
  %1674 = extractelement <2 x float> %1671, i64 1
  %1675 = tail call float @llvm.amdgcn.readlane.f32(float %1674, i32 63)
  %1676 = shufflevector <2 x float> %1281, <2 x float> %1284, <2 x i32> <i32 0, i32 2>
  %1677 = shufflevector <2 x float> %1281, <2 x float> %1284, <2 x i32> <i32 1, i32 3>
  %1678 = fadd <2 x float> %1676, %1677
  %1679 = extractelement <2 x float> %1678, i64 0
  %1680 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1679, i32 280, i32 15, i32 15, i1 true)
  %1681 = extractelement <2 x float> %1678, i64 1
  %1682 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1681, i32 280, i32 15, i32 15, i1 true)
  %1683 = insertelement <2 x float> poison, float %1680, i64 0
  %1684 = insertelement <2 x float> %1683, float %1682, i64 1
  %1685 = fadd <2 x float> %1678, %1684
  %1686 = extractelement <2 x float> %1685, i64 0
  %1687 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1686, i32 276, i32 15, i32 15, i1 true)
  %1688 = extractelement <2 x float> %1685, i64 1
  %1689 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1688, i32 276, i32 15, i32 15, i1 true)
  %1690 = insertelement <2 x float> poison, float %1687, i64 0
  %1691 = insertelement <2 x float> %1690, float %1689, i64 1
  %1692 = fadd <2 x float> %1685, %1691
  %1693 = extractelement <2 x float> %1692, i64 0
  %1694 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1693, i32 274, i32 15, i32 15, i1 true)
  %1695 = extractelement <2 x float> %1692, i64 1
  %1696 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1695, i32 274, i32 15, i32 15, i1 true)
  %1697 = insertelement <2 x float> poison, float %1694, i64 0
  %1698 = insertelement <2 x float> %1697, float %1696, i64 1
  %1699 = fadd <2 x float> %1692, %1698
  %1700 = extractelement <2 x float> %1699, i64 0
  %1701 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1700, i32 273, i32 15, i32 15, i1 true)
  %1702 = extractelement <2 x float> %1699, i64 1
  %1703 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1702, i32 273, i32 15, i32 15, i1 true)
  %1704 = insertelement <2 x float> poison, float %1701, i64 0
  %1705 = insertelement <2 x float> %1704, float %1703, i64 1
  %1706 = fadd <2 x float> %1699, %1705
  %1707 = extractelement <2 x float> %1706, i64 0
  %1708 = tail call float @llvm.amdgcn.update.dpp.f32(float %1707, float %1707, i32 322, i32 10, i32 15, i1 true)
  %1709 = extractelement <2 x float> %1706, i64 1
  %1710 = tail call float @llvm.amdgcn.update.dpp.f32(float %1709, float %1709, i32 322, i32 10, i32 15, i1 true)
  %1711 = insertelement <2 x float> poison, float %1708, i64 0
  %1712 = insertelement <2 x float> %1711, float %1710, i64 1
  %1713 = fadd <2 x float> %1706, %1712
  %1714 = extractelement <2 x float> %1713, i64 0
  %1715 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1714, i32 323, i32 15, i32 15, i1 true)
  %1716 = extractelement <2 x float> %1713, i64 1
  %1717 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1716, i32 323, i32 15, i32 15, i1 true)
  %1718 = insertelement <2 x float> poison, float %1715, i64 0
  %1719 = insertelement <2 x float> %1718, float %1717, i64 1
  %1720 = fadd <2 x float> %1713, %1719
  %1721 = extractelement <2 x float> %1720, i64 0
  %1722 = tail call float @llvm.amdgcn.readlane.f32(float %1721, i32 63)
  %1723 = extractelement <2 x float> %1720, i64 1
  %1724 = tail call float @llvm.amdgcn.readlane.f32(float %1723, i32 63)
  %1725 = shufflevector <2 x float> %1287, <2 x float> %1290, <2 x i32> <i32 0, i32 2>
  %1726 = shufflevector <2 x float> %1287, <2 x float> %1290, <2 x i32> <i32 1, i32 3>
  %1727 = fadd <2 x float> %1725, %1726
  %1728 = extractelement <2 x float> %1727, i64 0
  %1729 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1728, i32 280, i32 15, i32 15, i1 true)
  %1730 = extractelement <2 x float> %1727, i64 1
  %1731 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1730, i32 280, i32 15, i32 15, i1 true)
  %1732 = insertelement <2 x float> poison, float %1729, i64 0
  %1733 = insertelement <2 x float> %1732, float %1731, i64 1
  %1734 = fadd <2 x float> %1727, %1733
  %1735 = extractelement <2 x float> %1734, i64 0
  %1736 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1735, i32 276, i32 15, i32 15, i1 true)
  %1737 = extractelement <2 x float> %1734, i64 1
  %1738 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1737, i32 276, i32 15, i32 15, i1 true)
  %1739 = insertelement <2 x float> poison, float %1736, i64 0
  %1740 = insertelement <2 x float> %1739, float %1738, i64 1
  %1741 = fadd <2 x float> %1734, %1740
  %1742 = extractelement <2 x float> %1741, i64 0
  %1743 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1742, i32 274, i32 15, i32 15, i1 true)
  %1744 = extractelement <2 x float> %1741, i64 1
  %1745 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1744, i32 274, i32 15, i32 15, i1 true)
  %1746 = insertelement <2 x float> poison, float %1743, i64 0
  %1747 = insertelement <2 x float> %1746, float %1745, i64 1
  %1748 = fadd <2 x float> %1741, %1747
  %1749 = extractelement <2 x float> %1748, i64 0
  %1750 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1749, i32 273, i32 15, i32 15, i1 true)
  %1751 = extractelement <2 x float> %1748, i64 1
  %1752 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1751, i32 273, i32 15, i32 15, i1 true)
  %1753 = insertelement <2 x float> poison, float %1750, i64 0
  %1754 = insertelement <2 x float> %1753, float %1752, i64 1
  %1755 = fadd <2 x float> %1748, %1754
  %1756 = extractelement <2 x float> %1755, i64 0
  %1757 = tail call float @llvm.amdgcn.update.dpp.f32(float %1756, float %1756, i32 322, i32 10, i32 15, i1 true)
  %1758 = extractelement <2 x float> %1755, i64 1
  %1759 = tail call float @llvm.amdgcn.update.dpp.f32(float %1758, float %1758, i32 322, i32 10, i32 15, i1 true)
  %1760 = insertelement <2 x float> poison, float %1757, i64 0
  %1761 = insertelement <2 x float> %1760, float %1759, i64 1
  %1762 = fadd <2 x float> %1755, %1761
  %1763 = extractelement <2 x float> %1762, i64 0
  %1764 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1763, i32 323, i32 15, i32 15, i1 true)
  %1765 = extractelement <2 x float> %1762, i64 1
  %1766 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1765, i32 323, i32 15, i32 15, i1 true)
  %1767 = insertelement <2 x float> poison, float %1764, i64 0
  %1768 = insertelement <2 x float> %1767, float %1766, i64 1
  %1769 = fadd <2 x float> %1762, %1768
  %1770 = extractelement <2 x float> %1769, i64 0
  %1771 = tail call float @llvm.amdgcn.readlane.f32(float %1770, i32 63)
  %1772 = extractelement <2 x float> %1769, i64 1
  %1773 = tail call float @llvm.amdgcn.readlane.f32(float %1772, i32 63)
  %1774 = shufflevector <2 x float> %1293, <2 x float> %1296, <2 x i32> <i32 0, i32 2>
  %1775 = shufflevector <2 x float> %1293, <2 x float> %1296, <2 x i32> <i32 1, i32 3>
  %1776 = fadd <2 x float> %1774, %1775
  %1777 = extractelement <2 x float> %1776, i64 0
  %1778 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1777, i32 280, i32 15, i32 15, i1 true)
  %1779 = extractelement <2 x float> %1776, i64 1
  %1780 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1779, i32 280, i32 15, i32 15, i1 true)
  %1781 = insertelement <2 x float> poison, float %1778, i64 0
  %1782 = insertelement <2 x float> %1781, float %1780, i64 1
  %1783 = fadd <2 x float> %1776, %1782
  %1784 = extractelement <2 x float> %1783, i64 0
  %1785 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1784, i32 276, i32 15, i32 15, i1 true)
  %1786 = extractelement <2 x float> %1783, i64 1
  %1787 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1786, i32 276, i32 15, i32 15, i1 true)
  %1788 = insertelement <2 x float> poison, float %1785, i64 0
  %1789 = insertelement <2 x float> %1788, float %1787, i64 1
  %1790 = fadd <2 x float> %1783, %1789
  %1791 = extractelement <2 x float> %1790, i64 0
  %1792 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1791, i32 274, i32 15, i32 15, i1 true)
  %1793 = extractelement <2 x float> %1790, i64 1
  %1794 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1793, i32 274, i32 15, i32 15, i1 true)
  %1795 = insertelement <2 x float> poison, float %1792, i64 0
  %1796 = insertelement <2 x float> %1795, float %1794, i64 1
  %1797 = fadd <2 x float> %1790, %1796
  %1798 = extractelement <2 x float> %1797, i64 0
  %1799 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1798, i32 273, i32 15, i32 15, i1 true)
  %1800 = extractelement <2 x float> %1797, i64 1
  %1801 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1800, i32 273, i32 15, i32 15, i1 true)
  %1802 = insertelement <2 x float> poison, float %1799, i64 0
  %1803 = insertelement <2 x float> %1802, float %1801, i64 1
  %1804 = fadd <2 x float> %1797, %1803
  %1805 = extractelement <2 x float> %1804, i64 0
  %1806 = tail call float @llvm.amdgcn.update.dpp.f32(float %1805, float %1805, i32 322, i32 10, i32 15, i1 true)
  %1807 = extractelement <2 x float> %1804, i64 1
  %1808 = tail call float @llvm.amdgcn.update.dpp.f32(float %1807, float %1807, i32 322, i32 10, i32 15, i1 true)
  %1809 = insertelement <2 x float> poison, float %1806, i64 0
  %1810 = insertelement <2 x float> %1809, float %1808, i64 1
  %1811 = fadd <2 x float> %1804, %1810
  %1812 = extractelement <2 x float> %1811, i64 0
  %1813 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1812, i32 323, i32 15, i32 15, i1 true)
  %1814 = extractelement <2 x float> %1811, i64 1
  %1815 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1814, i32 323, i32 15, i32 15, i1 true)
  %1816 = insertelement <2 x float> poison, float %1813, i64 0
  %1817 = insertelement <2 x float> %1816, float %1815, i64 1
  %1818 = fadd <2 x float> %1811, %1817
  %1819 = extractelement <2 x float> %1818, i64 0
  %1820 = tail call float @llvm.amdgcn.readlane.f32(float %1819, i32 63)
  %1821 = extractelement <2 x float> %1818, i64 1
  %1822 = tail call float @llvm.amdgcn.readlane.f32(float %1821, i32 63)
  %1823 = shufflevector <2 x float> %1299, <2 x float> %1302, <2 x i32> <i32 0, i32 2>
  %1824 = shufflevector <2 x float> %1299, <2 x float> %1302, <2 x i32> <i32 1, i32 3>
  %1825 = fadd <2 x float> %1823, %1824
  %1826 = extractelement <2 x float> %1825, i64 0
  %1827 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1826, i32 280, i32 15, i32 15, i1 true)
  %1828 = extractelement <2 x float> %1825, i64 1
  %1829 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1828, i32 280, i32 15, i32 15, i1 true)
  %1830 = insertelement <2 x float> poison, float %1827, i64 0
  %1831 = insertelement <2 x float> %1830, float %1829, i64 1
  %1832 = fadd <2 x float> %1825, %1831
  %1833 = extractelement <2 x float> %1832, i64 0
  %1834 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1833, i32 276, i32 15, i32 15, i1 true)
  %1835 = extractelement <2 x float> %1832, i64 1
  %1836 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1835, i32 276, i32 15, i32 15, i1 true)
  %1837 = insertelement <2 x float> poison, float %1834, i64 0
  %1838 = insertelement <2 x float> %1837, float %1836, i64 1
  %1839 = fadd <2 x float> %1832, %1838
  %1840 = extractelement <2 x float> %1839, i64 0
  %1841 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1840, i32 274, i32 15, i32 15, i1 true)
  %1842 = extractelement <2 x float> %1839, i64 1
  %1843 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1842, i32 274, i32 15, i32 15, i1 true)
  %1844 = insertelement <2 x float> poison, float %1841, i64 0
  %1845 = insertelement <2 x float> %1844, float %1843, i64 1
  %1846 = fadd <2 x float> %1839, %1845
  %1847 = extractelement <2 x float> %1846, i64 0
  %1848 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1847, i32 273, i32 15, i32 15, i1 true)
  %1849 = extractelement <2 x float> %1846, i64 1
  %1850 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1849, i32 273, i32 15, i32 15, i1 true)
  %1851 = insertelement <2 x float> poison, float %1848, i64 0
  %1852 = insertelement <2 x float> %1851, float %1850, i64 1
  %1853 = fadd <2 x float> %1846, %1852
  %1854 = extractelement <2 x float> %1853, i64 0
  %1855 = tail call float @llvm.amdgcn.update.dpp.f32(float %1854, float %1854, i32 322, i32 10, i32 15, i1 true)
  %1856 = extractelement <2 x float> %1853, i64 1
  %1857 = tail call float @llvm.amdgcn.update.dpp.f32(float %1856, float %1856, i32 322, i32 10, i32 15, i1 true)
  %1858 = insertelement <2 x float> poison, float %1855, i64 0
  %1859 = insertelement <2 x float> %1858, float %1857, i64 1
  %1860 = fadd <2 x float> %1853, %1859
  %1861 = extractelement <2 x float> %1860, i64 0
  %1862 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1861, i32 323, i32 15, i32 15, i1 true)
  %1863 = extractelement <2 x float> %1860, i64 1
  %1864 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1863, i32 323, i32 15, i32 15, i1 true)
  %1865 = insertelement <2 x float> poison, float %1862, i64 0
  %1866 = insertelement <2 x float> %1865, float %1864, i64 1
  %1867 = fadd <2 x float> %1860, %1866
  %1868 = extractelement <2 x float> %1867, i64 0
  %1869 = tail call float @llvm.amdgcn.readlane.f32(float %1868, i32 63)
  %1870 = extractelement <2 x float> %1867, i64 1
  %1871 = tail call float @llvm.amdgcn.readlane.f32(float %1870, i32 63)
  %1872 = shufflevector <2 x float> %1305, <2 x float> %1308, <2 x i32> <i32 0, i32 2>
  %1873 = shufflevector <2 x float> %1305, <2 x float> %1308, <2 x i32> <i32 1, i32 3>
  %1874 = fadd <2 x float> %1872, %1873
  %1875 = extractelement <2 x float> %1874, i64 0
  %1876 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1875, i32 280, i32 15, i32 15, i1 true)
  %1877 = extractelement <2 x float> %1874, i64 1
  %1878 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1877, i32 280, i32 15, i32 15, i1 true)
  %1879 = insertelement <2 x float> poison, float %1876, i64 0
  %1880 = insertelement <2 x float> %1879, float %1878, i64 1
  %1881 = fadd <2 x float> %1874, %1880
  %1882 = extractelement <2 x float> %1881, i64 0
  %1883 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1882, i32 276, i32 15, i32 15, i1 true)
  %1884 = extractelement <2 x float> %1881, i64 1
  %1885 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1884, i32 276, i32 15, i32 15, i1 true)
  %1886 = insertelement <2 x float> poison, float %1883, i64 0
  %1887 = insertelement <2 x float> %1886, float %1885, i64 1
  %1888 = fadd <2 x float> %1881, %1887
  %1889 = extractelement <2 x float> %1888, i64 0
  %1890 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1889, i32 274, i32 15, i32 15, i1 true)
  %1891 = extractelement <2 x float> %1888, i64 1
  %1892 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1891, i32 274, i32 15, i32 15, i1 true)
  %1893 = insertelement <2 x float> poison, float %1890, i64 0
  %1894 = insertelement <2 x float> %1893, float %1892, i64 1
  %1895 = fadd <2 x float> %1888, %1894
  %1896 = extractelement <2 x float> %1895, i64 0
  %1897 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1896, i32 273, i32 15, i32 15, i1 true)
  %1898 = extractelement <2 x float> %1895, i64 1
  %1899 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1898, i32 273, i32 15, i32 15, i1 true)
  %1900 = insertelement <2 x float> poison, float %1897, i64 0
  %1901 = insertelement <2 x float> %1900, float %1899, i64 1
  %1902 = fadd <2 x float> %1895, %1901
  %1903 = extractelement <2 x float> %1902, i64 0
  %1904 = tail call float @llvm.amdgcn.update.dpp.f32(float %1903, float %1903, i32 322, i32 10, i32 15, i1 true)
  %1905 = extractelement <2 x float> %1902, i64 1
  %1906 = tail call float @llvm.amdgcn.update.dpp.f32(float %1905, float %1905, i32 322, i32 10, i32 15, i1 true)
  %1907 = insertelement <2 x float> poison, float %1904, i64 0
  %1908 = insertelement <2 x float> %1907, float %1906, i64 1
  %1909 = fadd <2 x float> %1902, %1908
  %1910 = extractelement <2 x float> %1909, i64 0
  %1911 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1910, i32 323, i32 15, i32 15, i1 true)
  %1912 = extractelement <2 x float> %1909, i64 1
  %1913 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1912, i32 323, i32 15, i32 15, i1 true)
  %1914 = insertelement <2 x float> poison, float %1911, i64 0
  %1915 = insertelement <2 x float> %1914, float %1913, i64 1
  %1916 = fadd <2 x float> %1909, %1915
  %1917 = extractelement <2 x float> %1916, i64 0
  %1918 = tail call float @llvm.amdgcn.readlane.f32(float %1917, i32 63)
  %1919 = extractelement <2 x float> %1916, i64 1
  %1920 = tail call float @llvm.amdgcn.readlane.f32(float %1919, i32 63)
  %1921 = shufflevector <2 x float> %1311, <2 x float> %1314, <2 x i32> <i32 0, i32 2>
  %1922 = shufflevector <2 x float> %1311, <2 x float> %1314, <2 x i32> <i32 1, i32 3>
  %1923 = fadd <2 x float> %1921, %1922
  %1924 = extractelement <2 x float> %1923, i64 0
  %1925 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1924, i32 280, i32 15, i32 15, i1 true)
  %1926 = extractelement <2 x float> %1923, i64 1
  %1927 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1926, i32 280, i32 15, i32 15, i1 true)
  %1928 = insertelement <2 x float> poison, float %1925, i64 0
  %1929 = insertelement <2 x float> %1928, float %1927, i64 1
  %1930 = fadd <2 x float> %1923, %1929
  %1931 = extractelement <2 x float> %1930, i64 0
  %1932 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1931, i32 276, i32 15, i32 15, i1 true)
  %1933 = extractelement <2 x float> %1930, i64 1
  %1934 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1933, i32 276, i32 15, i32 15, i1 true)
  %1935 = insertelement <2 x float> poison, float %1932, i64 0
  %1936 = insertelement <2 x float> %1935, float %1934, i64 1
  %1937 = fadd <2 x float> %1930, %1936
  %1938 = extractelement <2 x float> %1937, i64 0
  %1939 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1938, i32 274, i32 15, i32 15, i1 true)
  %1940 = extractelement <2 x float> %1937, i64 1
  %1941 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1940, i32 274, i32 15, i32 15, i1 true)
  %1942 = insertelement <2 x float> poison, float %1939, i64 0
  %1943 = insertelement <2 x float> %1942, float %1941, i64 1
  %1944 = fadd <2 x float> %1937, %1943
  %1945 = extractelement <2 x float> %1944, i64 0
  %1946 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1945, i32 273, i32 15, i32 15, i1 true)
  %1947 = extractelement <2 x float> %1944, i64 1
  %1948 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1947, i32 273, i32 15, i32 15, i1 true)
  %1949 = insertelement <2 x float> poison, float %1946, i64 0
  %1950 = insertelement <2 x float> %1949, float %1948, i64 1
  %1951 = fadd <2 x float> %1944, %1950
  %1952 = extractelement <2 x float> %1951, i64 0
  %1953 = tail call float @llvm.amdgcn.update.dpp.f32(float %1952, float %1952, i32 322, i32 10, i32 15, i1 true)
  %1954 = extractelement <2 x float> %1951, i64 1
  %1955 = tail call float @llvm.amdgcn.update.dpp.f32(float %1954, float %1954, i32 322, i32 10, i32 15, i1 true)
  %1956 = insertelement <2 x float> poison, float %1953, i64 0
  %1957 = insertelement <2 x float> %1956, float %1955, i64 1
  %1958 = fadd <2 x float> %1951, %1957
  %1959 = extractelement <2 x float> %1958, i64 0
  %1960 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1959, i32 323, i32 15, i32 15, i1 true)
  %1961 = extractelement <2 x float> %1958, i64 1
  %1962 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1961, i32 323, i32 15, i32 15, i1 true)
  %1963 = insertelement <2 x float> poison, float %1960, i64 0
  %1964 = insertelement <2 x float> %1963, float %1962, i64 1
  %1965 = fadd <2 x float> %1958, %1964
  %1966 = extractelement <2 x float> %1965, i64 0
  %1967 = tail call float @llvm.amdgcn.readlane.f32(float %1966, i32 63)
  %1968 = extractelement <2 x float> %1965, i64 1
  %1969 = tail call float @llvm.amdgcn.readlane.f32(float %1968, i32 63)
  %1970 = shufflevector <2 x float> %1317, <2 x float> %1320, <2 x i32> <i32 0, i32 2>
  %1971 = shufflevector <2 x float> %1317, <2 x float> %1320, <2 x i32> <i32 1, i32 3>
  %1972 = fadd <2 x float> %1970, %1971
  %1973 = extractelement <2 x float> %1972, i64 0
  %1974 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1973, i32 280, i32 15, i32 15, i1 true)
  %1975 = extractelement <2 x float> %1972, i64 1
  %1976 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1975, i32 280, i32 15, i32 15, i1 true)
  %1977 = insertelement <2 x float> poison, float %1974, i64 0
  %1978 = insertelement <2 x float> %1977, float %1976, i64 1
  %1979 = fadd <2 x float> %1972, %1978
  %1980 = extractelement <2 x float> %1979, i64 0
  %1981 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1980, i32 276, i32 15, i32 15, i1 true)
  %1982 = extractelement <2 x float> %1979, i64 1
  %1983 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1982, i32 276, i32 15, i32 15, i1 true)
  %1984 = insertelement <2 x float> poison, float %1981, i64 0
  %1985 = insertelement <2 x float> %1984, float %1983, i64 1
  %1986 = fadd <2 x float> %1979, %1985
  %1987 = extractelement <2 x float> %1986, i64 0
  %1988 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1987, i32 274, i32 15, i32 15, i1 true)
  %1989 = extractelement <2 x float> %1986, i64 1
  %1990 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1989, i32 274, i32 15, i32 15, i1 true)
  %1991 = insertelement <2 x float> poison, float %1988, i64 0
  %1992 = insertelement <2 x float> %1991, float %1990, i64 1
  %1993 = fadd <2 x float> %1986, %1992
  %1994 = extractelement <2 x float> %1993, i64 0
  %1995 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1994, i32 273, i32 15, i32 15, i1 true)
  %1996 = extractelement <2 x float> %1993, i64 1
  %1997 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %1996, i32 273, i32 15, i32 15, i1 true)
  %1998 = insertelement <2 x float> poison, float %1995, i64 0
  %1999 = insertelement <2 x float> %1998, float %1997, i64 1
  %2000 = fadd <2 x float> %1993, %1999
  %2001 = extractelement <2 x float> %2000, i64 0
  %2002 = tail call float @llvm.amdgcn.update.dpp.f32(float %2001, float %2001, i32 322, i32 10, i32 15, i1 true)
  %2003 = extractelement <2 x float> %2000, i64 1
  %2004 = tail call float @llvm.amdgcn.update.dpp.f32(float %2003, float %2003, i32 322, i32 10, i32 15, i1 true)
  %2005 = insertelement <2 x float> poison, float %2002, i64 0
  %2006 = insertelement <2 x float> %2005, float %2004, i64 1
  %2007 = fadd <2 x float> %2000, %2006
  %2008 = extractelement <2 x float> %2007, i64 0
  %2009 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2008, i32 323, i32 15, i32 15, i1 true)
  %2010 = extractelement <2 x float> %2007, i64 1
  %2011 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2010, i32 323, i32 15, i32 15, i1 true)
  %2012 = insertelement <2 x float> poison, float %2009, i64 0
  %2013 = insertelement <2 x float> %2012, float %2011, i64 1
  %2014 = fadd <2 x float> %2007, %2013
  %2015 = extractelement <2 x float> %2014, i64 0
  %2016 = tail call float @llvm.amdgcn.readlane.f32(float %2015, i32 63)
  %2017 = extractelement <2 x float> %2014, i64 1
  %2018 = tail call float @llvm.amdgcn.readlane.f32(float %2017, i32 63)
  %2019 = shufflevector <2 x float> %1323, <2 x float> %1326, <2 x i32> <i32 0, i32 2>
  %2020 = shufflevector <2 x float> %1323, <2 x float> %1326, <2 x i32> <i32 1, i32 3>
  %2021 = fadd <2 x float> %2019, %2020
  %2022 = extractelement <2 x float> %2021, i64 0
  %2023 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2022, i32 280, i32 15, i32 15, i1 true)
  %2024 = extractelement <2 x float> %2021, i64 1
  %2025 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2024, i32 280, i32 15, i32 15, i1 true)
  %2026 = insertelement <2 x float> poison, float %2023, i64 0
  %2027 = insertelement <2 x float> %2026, float %2025, i64 1
  %2028 = fadd <2 x float> %2021, %2027
  %2029 = extractelement <2 x float> %2028, i64 0
  %2030 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2029, i32 276, i32 15, i32 15, i1 true)
  %2031 = extractelement <2 x float> %2028, i64 1
  %2032 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2031, i32 276, i32 15, i32 15, i1 true)
  %2033 = insertelement <2 x float> poison, float %2030, i64 0
  %2034 = insertelement <2 x float> %2033, float %2032, i64 1
  %2035 = fadd <2 x float> %2028, %2034
  %2036 = extractelement <2 x float> %2035, i64 0
  %2037 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2036, i32 274, i32 15, i32 15, i1 true)
  %2038 = extractelement <2 x float> %2035, i64 1
  %2039 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2038, i32 274, i32 15, i32 15, i1 true)
  %2040 = insertelement <2 x float> poison, float %2037, i64 0
  %2041 = insertelement <2 x float> %2040, float %2039, i64 1
  %2042 = fadd <2 x float> %2035, %2041
  %2043 = extractelement <2 x float> %2042, i64 0
  %2044 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2043, i32 273, i32 15, i32 15, i1 true)
  %2045 = extractelement <2 x float> %2042, i64 1
  %2046 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2045, i32 273, i32 15, i32 15, i1 true)
  %2047 = insertelement <2 x float> poison, float %2044, i64 0
  %2048 = insertelement <2 x float> %2047, float %2046, i64 1
  %2049 = fadd <2 x float> %2042, %2048
  %2050 = extractelement <2 x float> %2049, i64 0
  %2051 = tail call float @llvm.amdgcn.update.dpp.f32(float %2050, float %2050, i32 322, i32 10, i32 15, i1 true)
  %2052 = extractelement <2 x float> %2049, i64 1
  %2053 = tail call float @llvm.amdgcn.update.dpp.f32(float %2052, float %2052, i32 322, i32 10, i32 15, i1 true)
  %2054 = insertelement <2 x float> poison, float %2051, i64 0
  %2055 = insertelement <2 x float> %2054, float %2053, i64 1
  %2056 = fadd <2 x float> %2049, %2055
  %2057 = extractelement <2 x float> %2056, i64 0
  %2058 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2057, i32 323, i32 15, i32 15, i1 true)
  %2059 = extractelement <2 x float> %2056, i64 1
  %2060 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2059, i32 323, i32 15, i32 15, i1 true)
  %2061 = insertelement <2 x float> poison, float %2058, i64 0
  %2062 = insertelement <2 x float> %2061, float %2060, i64 1
  %2063 = fadd <2 x float> %2056, %2062
  %2064 = extractelement <2 x float> %2063, i64 0
  %2065 = tail call float @llvm.amdgcn.readlane.f32(float %2064, i32 63)
  %2066 = extractelement <2 x float> %2063, i64 1
  %2067 = tail call float @llvm.amdgcn.readlane.f32(float %2066, i32 63)
  %2068 = shufflevector <2 x float> %1329, <2 x float> %1332, <2 x i32> <i32 0, i32 2>
  %2069 = shufflevector <2 x float> %1329, <2 x float> %1332, <2 x i32> <i32 1, i32 3>
  %2070 = fadd <2 x float> %2068, %2069
  %2071 = extractelement <2 x float> %2070, i64 0
  %2072 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2071, i32 280, i32 15, i32 15, i1 true)
  %2073 = extractelement <2 x float> %2070, i64 1
  %2074 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2073, i32 280, i32 15, i32 15, i1 true)
  %2075 = insertelement <2 x float> poison, float %2072, i64 0
  %2076 = insertelement <2 x float> %2075, float %2074, i64 1
  %2077 = fadd <2 x float> %2070, %2076
  %2078 = extractelement <2 x float> %2077, i64 0
  %2079 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2078, i32 276, i32 15, i32 15, i1 true)
  %2080 = extractelement <2 x float> %2077, i64 1
  %2081 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2080, i32 276, i32 15, i32 15, i1 true)
  %2082 = insertelement <2 x float> poison, float %2079, i64 0
  %2083 = insertelement <2 x float> %2082, float %2081, i64 1
  %2084 = fadd <2 x float> %2077, %2083
  %2085 = extractelement <2 x float> %2084, i64 0
  %2086 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2085, i32 274, i32 15, i32 15, i1 true)
  %2087 = extractelement <2 x float> %2084, i64 1
  %2088 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2087, i32 274, i32 15, i32 15, i1 true)
  %2089 = insertelement <2 x float> poison, float %2086, i64 0
  %2090 = insertelement <2 x float> %2089, float %2088, i64 1
  %2091 = fadd <2 x float> %2084, %2090
  %2092 = extractelement <2 x float> %2091, i64 0
  %2093 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2092, i32 273, i32 15, i32 15, i1 true)
  %2094 = extractelement <2 x float> %2091, i64 1
  %2095 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2094, i32 273, i32 15, i32 15, i1 true)
  %2096 = insertelement <2 x float> poison, float %2093, i64 0
  %2097 = insertelement <2 x float> %2096, float %2095, i64 1
  %2098 = fadd <2 x float> %2091, %2097
  %2099 = extractelement <2 x float> %2098, i64 0
  %2100 = tail call float @llvm.amdgcn.update.dpp.f32(float %2099, float %2099, i32 322, i32 10, i32 15, i1 true)
  %2101 = extractelement <2 x float> %2098, i64 1
  %2102 = tail call float @llvm.amdgcn.update.dpp.f32(float %2101, float %2101, i32 322, i32 10, i32 15, i1 true)
  %2103 = insertelement <2 x float> poison, float %2100, i64 0
  %2104 = insertelement <2 x float> %2103, float %2102, i64 1
  %2105 = fadd <2 x float> %2098, %2104
  %2106 = extractelement <2 x float> %2105, i64 0
  %2107 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2106, i32 323, i32 15, i32 15, i1 true)
  %2108 = extractelement <2 x float> %2105, i64 1
  %2109 = tail call float @llvm.amdgcn.update.dpp.f32(float poison, float %2108, i32 323, i32 15, i32 15, i1 true)
  %2110 = insertelement <2 x float> poison, float %2107, i64 0
  %2111 = insertelement <2 x float> %2110, float %2109, i64 1
  %2112 = fadd <2 x float> %2105, %2111
  %2113 = extractelement <2 x float> %2112, i64 0
  %2114 = tail call float @llvm.amdgcn.readlane.f32(float %2113, i32 63)
  %2115 = extractelement <2 x float> %2112, i64 1
  %2116 = tail call float @llvm.amdgcn.readlane.f32(float %2115, i32 63)
  %2117 = mul i32 %61, %58
  %2118 = add i32 %2117, %57
  %2119 = mul i32 %2118, %11
  %2120 = sext i32 %2119 to i64
  %2121 = getelementptr [4 x i8], ptr addrspace(1) %2, i64 %2120
  %2122 = sext i32 %21 to i64
  %2123 = getelementptr [4 x i8], ptr addrspace(1) %2121, i64 %2122
  %2124 = add i32 %21, 128
  %2125 = sub i32 %2124, %208
  %2126 = icmp sgt i32 %2125, 0
  br i1 %2126, label %2127, label %2185

2127:                                             ; preds = %851
  %2128 = sub nsw i32 128, %2125
  %2129 = icmp sgt i32 %2128, %24
  %2130 = getelementptr inbounds nuw i8, ptr addrspace(3) @global_smem, i32 %23
  %2131 = insertelement <4 x float> poison, float %1379, i64 0
  %2132 = insertelement <4 x float> %2131, float %1381, i64 1
  %2133 = insertelement <4 x float> %2132, float %1428, i64 2
  %2134 = insertelement <4 x float> %2133, float %1430, i64 3
  store <4 x float> %2134, ptr addrspace(3) %2130, align 16
  %2135 = getelementptr inbounds nuw i8, ptr addrspace(3) %2130, i32 16
  %2136 = insertelement <4 x float> poison, float %1477, i64 0
  %2137 = insertelement <4 x float> %2136, float %1479, i64 1
  %2138 = insertelement <4 x float> %2137, float %1526, i64 2
  %2139 = insertelement <4 x float> %2138, float %1528, i64 3
  store <4 x float> %2139, ptr addrspace(3) %2135, align 16
  %2140 = getelementptr inbounds nuw i8, ptr addrspace(3) %2130, i32 32
  %2141 = insertelement <4 x float> poison, float %1575, i64 0
  %2142 = insertelement <4 x float> %2141, float %1577, i64 1
  %2143 = insertelement <4 x float> %2142, float %1624, i64 2
  %2144 = insertelement <4 x float> %2143, float %1626, i64 3
  store <4 x float> %2144, ptr addrspace(3) %2140, align 16
  %2145 = getelementptr inbounds nuw i8, ptr addrspace(3) %2130, i32 48
  %2146 = insertelement <4 x float> poison, float %1673, i64 0
  %2147 = insertelement <4 x float> %2146, float %1675, i64 1
  %2148 = insertelement <4 x float> %2147, float %1722, i64 2
  %2149 = insertelement <4 x float> %2148, float %1724, i64 3
  store <4 x float> %2149, ptr addrspace(3) %2145, align 16
  %2150 = getelementptr inbounds nuw i8, ptr addrspace(3) %2130, i32 256
  %2151 = insertelement <4 x float> poison, float %1771, i64 0
  %2152 = insertelement <4 x float> %2151, float %1773, i64 1
  %2153 = insertelement <4 x float> %2152, float %1820, i64 2
  %2154 = insertelement <4 x float> %2153, float %1822, i64 3
  store <4 x float> %2154, ptr addrspace(3) %2150, align 16
  %2155 = getelementptr inbounds nuw i8, ptr addrspace(3) %2130, i32 272
  %2156 = insertelement <4 x float> poison, float %1869, i64 0
  %2157 = insertelement <4 x float> %2156, float %1871, i64 1
  %2158 = insertelement <4 x float> %2157, float %1918, i64 2
  %2159 = insertelement <4 x float> %2158, float %1920, i64 3
  store <4 x float> %2159, ptr addrspace(3) %2155, align 16
  %2160 = getelementptr inbounds nuw i8, ptr addrspace(3) %2130, i32 288
  %2161 = insertelement <4 x float> poison, float %1967, i64 0
  %2162 = insertelement <4 x float> %2161, float %1969, i64 1
  %2163 = insertelement <4 x float> %2162, float %2016, i64 2
  %2164 = insertelement <4 x float> %2163, float %2018, i64 3
  store <4 x float> %2164, ptr addrspace(3) %2160, align 16
  %2165 = getelementptr inbounds nuw i8, ptr addrspace(3) %2130, i32 304
  %2166 = insertelement <4 x float> poison, float %2065, i64 0
  %2167 = insertelement <4 x float> %2166, float %2067, i64 1
  %2168 = insertelement <4 x float> %2167, float %2114, i64 2
  %2169 = insertelement <4 x float> %2168, float %2116, i64 3
  store <4 x float> %2169, ptr addrspace(3) %2165, align 16
  fence syncscope("workgroup") release, !mmra !8
  tail call void @llvm.amdgcn.s.barrier()
  fence syncscope("workgroup") acquire, !mmra !8
  %2170 = shl nuw nsw i32 %16, 6
  %2171 = and i32 %2170, 192
  %2172 = and i32 %16, 60
  %2173 = shl nuw nsw i32 %19, 8
  %2174 = and i32 %2173, 256
  %2175 = getelementptr inbounds nuw i8, ptr addrspace(3) @global_smem, i32 %2171
  %2176 = getelementptr inbounds nuw i8, ptr addrspace(3) %2175, i32 %2174
  %2177 = getelementptr inbounds nuw i8, ptr addrspace(3) %2176, i32 %2172
  %2178 = load float, ptr addrspace(3) %2177, align 4
  %2179 = tail call ptr addrspace(8) @llvm.amdgcn.make.buffer.rsrc.p8.p1(ptr addrspace(1) %2123, i16 0, i64 2147483646, i32 159744)
  %2180 = and i32 %17, 128
  %2181 = icmp eq i32 %2180, 0
  %2182 = and i1 %2181, %2129
  %2183 = shl nuw nsw i32 %24, 2
  %2184 = select i1 %2182, i32 %2183, i32 -2147483648
  tail call void @llvm.amdgcn.raw.ptr.buffer.store.f32(float %2178, ptr addrspace(8) %2179, i32 %2184, i32 0, i32 0)
  br label %2240

2185:                                             ; preds = %851
  %2186 = getelementptr inbounds nuw i8, ptr addrspace(3) @global_smem, i32 %23
  %2187 = insertelement <4 x float> poison, float %1379, i64 0
  %2188 = insertelement <4 x float> %2187, float %1381, i64 1
  %2189 = insertelement <4 x float> %2188, float %1428, i64 2
  %2190 = insertelement <4 x float> %2189, float %1430, i64 3
  store <4 x float> %2190, ptr addrspace(3) %2186, align 16
  %2191 = getelementptr inbounds nuw i8, ptr addrspace(3) %2186, i32 16
  %2192 = insertelement <4 x float> poison, float %1477, i64 0
  %2193 = insertelement <4 x float> %2192, float %1479, i64 1
  %2194 = insertelement <4 x float> %2193, float %1526, i64 2
  %2195 = insertelement <4 x float> %2194, float %1528, i64 3
  store <4 x float> %2195, ptr addrspace(3) %2191, align 16
  %2196 = getelementptr inbounds nuw i8, ptr addrspace(3) %2186, i32 32
  %2197 = insertelement <4 x float> poison, float %1575, i64 0
  %2198 = insertelement <4 x float> %2197, float %1577, i64 1
  %2199 = insertelement <4 x float> %2198, float %1624, i64 2
  %2200 = insertelement <4 x float> %2199, float %1626, i64 3
  store <4 x float> %2200, ptr addrspace(3) %2196, align 16
  %2201 = getelementptr inbounds nuw i8, ptr addrspace(3) %2186, i32 48
  %2202 = insertelement <4 x float> poison, float %1673, i64 0
  %2203 = insertelement <4 x float> %2202, float %1675, i64 1
  %2204 = insertelement <4 x float> %2203, float %1722, i64 2
  %2205 = insertelement <4 x float> %2204, float %1724, i64 3
  store <4 x float> %2205, ptr addrspace(3) %2201, align 16
  %2206 = getelementptr inbounds nuw i8, ptr addrspace(3) %2186, i32 256
  %2207 = insertelement <4 x float> poison, float %1771, i64 0
  %2208 = insertelement <4 x float> %2207, float %1773, i64 1
  %2209 = insertelement <4 x float> %2208, float %1820, i64 2
  %2210 = insertelement <4 x float> %2209, float %1822, i64 3
  store <4 x float> %2210, ptr addrspace(3) %2206, align 16
  %2211 = getelementptr inbounds nuw i8, ptr addrspace(3) %2186, i32 272
  %2212 = insertelement <4 x float> poison, float %1869, i64 0
  %2213 = insertelement <4 x float> %2212, float %1871, i64 1
  %2214 = insertelement <4 x float> %2213, float %1918, i64 2
  %2215 = insertelement <4 x float> %2214, float %1920, i64 3
  store <4 x float> %2215, ptr addrspace(3) %2211, align 16
  %2216 = getelementptr inbounds nuw i8, ptr addrspace(3) %2186, i32 288
  %2217 = insertelement <4 x float> poison, float %1967, i64 0
  %2218 = insertelement <4 x float> %2217, float %1969, i64 1
  %2219 = insertelement <4 x float> %2218, float %2016, i64 2
  %2220 = insertelement <4 x float> %2219, float %2018, i64 3
  store <4 x float> %2220, ptr addrspace(3) %2216, align 16
  %2221 = getelementptr inbounds nuw i8, ptr addrspace(3) %2186, i32 304
  %2222 = insertelement <4 x float> poison, float %2065, i64 0
  %2223 = insertelement <4 x float> %2222, float %2067, i64 1
  %2224 = insertelement <4 x float> %2223, float %2114, i64 2
  %2225 = insertelement <4 x float> %2224, float %2116, i64 3
  store <4 x float> %2225, ptr addrspace(3) %2221, align 16
  fence syncscope("workgroup") release, !mmra !8
  tail call void @llvm.amdgcn.s.barrier()
  fence syncscope("workgroup") acquire, !mmra !8
  %2226 = shl nuw nsw i32 %16, 6
  %2227 = and i32 %2226, 192
  %2228 = and i32 %16, 60
  %2229 = shl nuw nsw i32 %19, 8
  %2230 = and i32 %2229, 256
  %2231 = getelementptr inbounds nuw i8, ptr addrspace(3) @global_smem, i32 %2227
  %2232 = getelementptr inbounds nuw i8, ptr addrspace(3) %2231, i32 %2230
  %2233 = getelementptr inbounds nuw i8, ptr addrspace(3) %2232, i32 %2228
  %2234 = load float, ptr addrspace(3) %2233, align 4
  %2235 = tail call ptr addrspace(8) @llvm.amdgcn.make.buffer.rsrc.p8.p1(ptr addrspace(1) %2123, i16 0, i64 2147483646, i32 159744)
  %2236 = and i32 %17, 128
  %2237 = icmp eq i32 %2236, 0
  %2238 = shl nuw nsw i32 %24, 2
  %2239 = select i1 %2237, i32 %2238, i32 -2147483648
  tail call void @llvm.amdgcn.raw.ptr.buffer.store.f32(float %2234, ptr addrspace(8) %2235, i32 %2239, i32 0, i32 0)
  br label %2240

2240:                                             ; preds = %2127, %2185
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef range(i32 0, 1024) i32 @llvm.amdgcn.workitem.id.x() #1

; Function Attrs: convergent mustprogress nocallback nocreateundeforpoison nofree nounwind willreturn memory(none)
declare i32 @llvm.amdgcn.readfirstlane.i32(i32) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.amdgcn.workgroup.id.x() #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.amdgcn.workgroup.id.y() #1

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef i32 @llvm.amdgcn.workgroup.id.z() #1

; Function Attrs: convergent mustprogress nocallback nofree nounwind willreturn memory(none)
declare float @llvm.amdgcn.update.dpp.f32(float, float, i32 immarg, i32 immarg, i32 immarg, i1 immarg) #3

; Function Attrs: convergent mustprogress nocallback nofree nounwind willreturn
declare void @llvm.amdgcn.s.barrier() #4

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare ptr addrspace(8) @llvm.amdgcn.make.buffer.rsrc.p8.p1(ptr addrspace(1) readnone, i16, i64, i32) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write)
declare void @llvm.amdgcn.raw.ptr.buffer.store.f32(float, ptr addrspace(8) writeonly captures(none), i32, i32, i32 immarg) #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare noundef align 4 ptr addrspace(4) @llvm.amdgcn.implicitarg.ptr() #1

; Function Attrs: convergent nocallback nofree nounwind willreturn memory(none)
declare float @llvm.amdgcn.readlane.f32(float, i32) #7

attributes #0 = { mustprogress norecurse nounwind willreturn "amdgpu-agpr-alloc"="0" "amdgpu-cluster-dims"="1,1,1" "amdgpu-flat-work-group-size"="1,256" "amdgpu-no-cluster-id-x" "amdgpu-no-cluster-id-y" "amdgpu-no-cluster-id-z" "amdgpu-no-completion-action" "amdgpu-no-default-queue" "amdgpu-no-dispatch-id" "amdgpu-no-dispatch-ptr" "amdgpu-no-flat-scratch-init" "amdgpu-no-heap-ptr" "amdgpu-no-hostcall-ptr" "amdgpu-no-lds-kernel-id" "amdgpu-no-multigrid-sync-arg" "amdgpu-no-queue-ptr" "amdgpu-no-workgroup-id-x" "amdgpu-no-workitem-id-x" "amdgpu-no-workitem-id-y" "amdgpu-no-workitem-id-z" "amdgpu-no-wwm" "amdgpu-waves-per-eu"="2, 2" "denormal-fp-math-f32"="ieee" "uniform-work-group-size" }
attributes #1 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { convergent mustprogress nocallback nocreateundeforpoison nofree nounwind willreturn memory(none) }
attributes #3 = { convergent mustprogress nocallback nofree nounwind willreturn memory(none) }
attributes #4 = { convergent mustprogress nocallback nofree nounwind willreturn }
attributes #5 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #6 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: write) }
attributes #7 = { convergent nocallback nofree nounwind willreturn memory(none) }

!llvm.module.flags = !{!0, !1, !2, !3}

!0 = !{i32 2, !"Debug Info Version", i32 3}
!1 = !{i32 1, !"amdhsa_code_object_version", i32 500}
!2 = !{i32 1, !"wchar_size", i32 4}
!3 = !{i32 8, !"PIC Level", i32 0}
!4 = !{!5, !5, i64 0}
!5 = !{!"int", !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C/C++ TBAA"}
!8 = !{!"amdgpu-synchronize-as", !"local"}
